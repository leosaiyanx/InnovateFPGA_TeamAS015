/*
 * imu_access.cpp
 *
 *  Created on: Jan 1, 2018
 *  Modified on: Feb 1, 2018
 *      Author: Lloyd Emokpae
 *      Description:
 *      			 The module contains routines to access the 9DOF IMU to:
 *      			 (1) Print Gyro, Accel and Mag to screen
 *      			 (2) Print heading and orientation to screen
 */

 #include <unistd.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <termios.h>
 #include <string.h>
 #include <stdint.h>
 #include <math.h>
 #include "imu_access.h"
 #include "global_variables.h"
 #include "imu_interface_lsm.h"

 using namespace std;
/********************************************************
* FUNCTION: initSensor
* DESCRIPTION: Initializes the LSM9DS0 driver.
**********************************************************/
int initSensor(LSM9DS0 & dof, void * base_addr_gyro, void * base_addr_xm)
{
	/*//uint16_t status = dof.begin(dof.G_SCALE_2000DPS, dof.A_SCALE_6G, dof.M_SCALE_2GS, dof.G_ODR_95_BW_25, dof.A_ODR_1600, dof.M_ODR_25);
	uint16_t status = dof.begin(dof.G_SCALE_2000DPS, dof.A_SCALE_6G, dof.M_SCALE_2GS, dof.G_ODR_95_BW_25, dof.A_ODR_25, dof.M_ODR_25);
	//dof.setAccelABW(dof.A_ABW_773);
	dof.setAccelODR(dof.A_ODR_100); // Set accelerometer update rate at 100 Hz
	//dof.setAccelODR(dof.A_ODR_1600); // Set accelerometer update rate at 1600 Hz
	dof.setAccelABW(dof.A_ABW_50); // Choose lowest filter setting for low noise
	dof.setGyroODR(dof.G_ODR_190_BW_125);  // Set gyro update rate to 190 Hz with the smallest bandwidth for low noise
	dof.setMagODR(dof.M_ODR_125); // Set magnetometer to update every 80 ms*/

	dof.setBaseAddrGYRO(base_addr_gyro);
	dof.setBaseAddrXM(base_addr_xm);

	uint16_t status = dof.begin();

	// Set data output ranges; choose lowest ranges for maximum resolution
	// Accelerometer scale can be: A_SCALE_2G, A_SCALE_4G, A_SCALE_6G, A_SCALE_8G, or A_SCALE_16G
	dof.setAccelScale(dof.A_SCALE_2G);

	// Gyro scale can be:  G_SCALE__245, G_SCALE__500, or G_SCALE__2000DPS
	dof.setGyroScale(dof.G_SCALE_245DPS);

	// Magnetometer scale can be: M_SCALE_2GS, M_SCALE_4GS, M_SCALE_8GS, M_SCALE_12GS
	dof.setMagScale(dof.M_SCALE_2GS);

	// Set output data rates
	// Accelerometer output data rate (ODR) can be: A_ODR_3125 (3.225 Hz), A_ODR_625 (6.25 Hz), A_ODR_125 (12.5 Hz), A_ODR_25, A_ODR_50,
	//                                              A_ODR_100,  A_ODR_200, A_ODR_400, A_ODR_800, A_ODR_1600 (1600 Hz)
	dof.setAccelODR(dof.A_ODR_200); // Set accelerometer update rate at 100 Hz

	// Accelerometer anti-aliasing filter rate can be 50, 194, 362, or 763 Hz
	// Anti-aliasing acts like a low-pass filter allowing oversampling of accelerometer and rejection of high-frequency spurious noise.
	// Strategy here is to effectively oversample accelerometer at 100 Hz and use a 50 Hz anti-aliasing (low-pass) filter frequency
	// to get a smooth ~150 Hz filter update rate
	dof.setAccelABW(dof.A_ABW_50); // Choose lowest filter setting for low noise

	// Gyro output data rates can be: 95 Hz (bandwidth 12.5 or 25 Hz), 190 Hz (bandwidth 12.5, 25, 50, or 70 Hz)
	//                                 380 Hz (bandwidth 20, 25, 50, 100 Hz), or 760 Hz (bandwidth 30, 35, 50, 100 Hz)
	dof.setGyroODR(dof.G_ODR_190_BW_125);  // Set gyro update rate to 190 Hz with the smallest bandwidth for low noise

	// Magnetometer output data rate can be: 3.125 (ODR_3125), 6.25 (ODR_625), 12.5 (ODR_125), 25, 50, or 100 Hz
	dof.setMagODR(dof.M_ODR_125); // Set magnetometer to update every 80 ms


	return status;
}
/**********************************************************************************************
* FUNCTION: fuseIMU
* DESCRIPTION: Read just the accelerometer data or fuse data from all three sensors
* 			   depending on the mode of operation. Modes include:
* 			   (1) Fuse all three sensors with an extended Kalman filter
* 			   (2) Fuse Accel and gyro with Complementary filter
* 			   (3) Use only Accel data.
*
***********************************************************************************************/
void fuseIMU(LSM9DS0 & dof, float theta_rot_deg, float deltat, float abias[3], float gbias[3])
{
	// Extended Kalman Filter
	if (FUSE_MODE == EXTENDED_KALMAN_FILTER)
	{
		fuseSensor(dof, theta_rot_deg, deltat, abias, gbias);
	}
	// Complementary Filter
	else if (FUSE_MODE == COMPLEMENTARY_FILTER)
	{
		complementaryFilter(dof, theta_rot_deg, deltat);
	}
	// Accel Only
	else if (FUSE_MODE == ACCEL_FILTER)
	{
		accelFilter(dof, theta_rot_deg, abias);
	}
	// Accel + Magnetometer Only
	else if (FUSE_MODE == ACCEL_MAG_FILTER)
	{
		accelMFilter(dof, theta_rot_deg, abias);
	}
}
/**********************************************************************************************
* FUNCTION: fuseSensor
* DESCRIPTION: Fuses the sensor data from all three sources
* 			   Accel, Gyro, Mag. (MadgwickQuaternionUpdate)
*
* REFERENCES:  [1] http://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles
* 			   [2] A.M. Sabatini, "Quaternion-Based Extended Kalman Filter for Determining
* 				   Orientation by Inertial and Magnetic Sensing", IEEE Transactions on Bio
* 				   Medical Engineering, Vol. 53, No. 7, 2006
***********************************************************************************************/
void fuseSensor(LSM9DS0 & dof, float theta_rot_deg, float deltat, float abias[3], float gbias[3])
{
	float q1 = dof.q[0], q2 = dof.q[1], q3 = dof.q[2], q4 = dof.q[3];   // short name local variable for readability
	float norm;
	float hx, hy, _2bx, _2bz;
	float s1, s2, s3, s4;
	float qDot1, qDot2, qDot3, qDot4;
	float ax, ay, az, gx, gy, gz, mx, my, mz;

	// Auxiliary variables to avoid repeated arithmetic
	float _2q1mx;
	float _2q1my;
	float _2q1mz;
	float _2q2mx;
	float _4bx;
	float _4bz;
	float _2q1 = 2.0f * q1;
	float _2q2 = 2.0f * q2;
	float _2q3 = 2.0f * q3;
	float _2q4 = 2.0f * q4;
	float _2q1q3 = 2.0f * q1 * q3;
	float _2q3q4 = 2.0f * q3 * q4;
	float q1q1 = q1 * q1;
	float q1q2 = q1 * q2;
	float q1q3 = q1 * q3;
	float q1q4 = q1 * q4;
	float q2q2 = q2 * q2;
	float q2q3 = q2 * q3;
	float q2q4 = q2 * q4;
	float q3q3 = q3 * q3;
	float q3q4 = q3 * q4;
	float q4q4 = q4 * q4;

	// Calculate the accelerometer, gyro and magnetometer data
	dof.readAccel();         		// Read raw accelerometer data
	ax = dof.calcAccel(dof.ax) - abias[0];  // Convert to g's, remove accelerometer biases
	ay = dof.calcAccel(dof.ay) - abias[1];
	az = dof.calcAccel(dof.az) - abias[2];

	dof.readGyro();           				// Read raw gyro data
	gx = dof.calcGyro(dof.gx) - gbias[0];   // Convert to degrees per seconds, remove gyro biases
	gy = dof.calcGyro(dof.gy) - gbias[1];
	gz = dof.calcGyro(dof.gz) - gbias[2];
	gx = gx * DEGREES_TO_RAD_SCALE;//(gx * M_PI)/180.0f;
	gy = gy * DEGREES_TO_RAD_SCALE;//(gy * M_PI)/180.0f;
	gz = gz * DEGREES_TO_RAD_SCALE;//(gz * M_PI)/180.0f;

	dof.readMag();           				// Read raw magnetometer data
	mx = dof.calcMag(dof.mx);     			// Convert to Gauss
	my = dof.calcMag(dof.my);
	mz = dof.calcMag(dof.mz);


	// Rotate the data based on the platform's orientation (i.e., quadcopter frame/mount)
	// Use the rotation matrix Rz and rotate around the z-axis, i.e.:
	// http://en.wikipedia.org/wiki/Rotation_matrix
	if (theta_rot_deg > 0.0f)
	{
		float theta_rot = theta_rot_deg * DEGREES_TO_RAD_SCALE;//(theta_rot_deg * M_PI) / 180.0f;
		float ax_r = (ax * cos(theta_rot)) - (ay * sin(theta_rot)) + 0.0f;
		float ay_r = (ax * sin(theta_rot)) + (ay * cos(theta_rot)) + 0.0f;
		float az_r = 0.0f + 0.0f + az;
		ax = ax_r;
		ay = ay_r;
		az = az_r;

		float gx_r = (gx * cos(theta_rot)) - (gy * sin(theta_rot)) + 0.0f;
		float gy_r = (gx * sin(theta_rot)) + (gy * cos(theta_rot)) + 0.0f;
		float gz_r = 0.0f + 0.0f + gz;
		gx = gx_r;
		gy = gy_r;
		gz = gz_r;

		float mx_r = (mx * cos(theta_rot)) - (my * sin(theta_rot)) + 0.0f;
		float my_r = (mx * sin(theta_rot)) + (my * cos(theta_rot)) + 0.0f;
		float mz_r = 0.0f + 0.0f + mz;
		mx = mx_r;
		my = my_r;
		mz = mz_r;
	}

	// Normalize accelerometer measurement
	norm = sqrt(ax * ax + ay * ay + az * az);
	if (norm == 0.0f) return; // handle NaN
	norm = 1.0f/norm;
	ax *= norm;
	ay *= norm;
	az *= norm;

	// Normalise magnetometer measurement
	norm = sqrt(mx * mx + my * my + mz * mz);
	if (norm == 0.0f) return; // handle NaN
	norm = 1.0f/norm;
	mx *= norm;
	my *= norm;
	mz *= norm;

	// Reference direction of Earth's magnetic field
	_2q1mx = 2.0f * q1 * mx;
	_2q1my = 2.0f * q1 * my;
	_2q1mz = 2.0f * q1 * mz;
	_2q2mx = 2.0f * q2 * mx;
	hx = mx * q1q1 - _2q1my * q4 + _2q1mz * q3 + mx * q2q2 + _2q2 * my * q3 + _2q2 * mz * q4 - mx * q3q3 - mx * q4q4;
	hy = _2q1mx * q4 + my * q1q1 - _2q1mz * q2 + _2q2mx * q3 - my * q2q2 + my * q3q3 + _2q3 * mz * q4 - my * q4q4;
	_2bx = sqrt(hx * hx + hy * hy);
	_2bz = -_2q1mx * q3 + _2q1my * q2 + mz * q1q1 + _2q2mx * q4 - mz * q2q2 + _2q3 * my * q4 - mz * q3q3 + mz * q4q4;
	_4bx = 2.0f * _2bx;
	_4bz = 2.0f * _2bz;

	// Gradient decent algorithm corrective step
	s1 = -_2q3 * (2.0f * q2q4 - _2q1q3 - ax) + _2q2 * (2.0f * q1q2 + _2q3q4 - ay) - _2bz * q3 * (_2bx * (0.5f - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx) + (-_2bx * q4 + _2bz * q2) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my) + _2bx * q3 * (_2bx * (q1q3 + q2q4) + _2bz * (0.5f - q2q2 - q3q3) - mz);
	s2 = _2q4 * (2.0f * q2q4 - _2q1q3 - ax) + _2q1 * (2.0f * q1q2 + _2q3q4 - ay) - 4.0f * q2 * (1.0f - 2.0f * q2q2 - 2.0f * q3q3 - az) + _2bz * q4 * (_2bx * (0.5f - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx) + (_2bx * q3 + _2bz * q1) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my) + (_2bx * q4 - _4bz * q2) * (_2bx * (q1q3 + q2q4) + _2bz * (0.5f - q2q2 - q3q3) - mz);
	s3 = -_2q1 * (2.0f * q2q4 - _2q1q3 - ax) + _2q4 * (2.0f * q1q2 + _2q3q4 - ay) - 4.0f * q3 * (1.0f - 2.0f * q2q2 - 2.0f * q3q3 - az) + (-_4bx * q3 - _2bz * q1) * (_2bx * (0.5f - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx) + (_2bx * q2 + _2bz * q4) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my) + (_2bx * q1 - _4bz * q3) * (_2bx * (q1q3 + q2q4) + _2bz * (0.5f - q2q2 - q3q3) - mz);
	s4 = _2q2 * (2.0f * q2q4 - _2q1q3 - ax) + _2q3 * (2.0f * q1q2 + _2q3q4 - ay) + (-_4bx * q4 + _2bz * q2) * (_2bx * (0.5f - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx) + (-_2bx * q1 + _2bz * q3) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my) + _2bx * q2 * (_2bx * (q1q3 + q2q4) + _2bz * (0.5f - q2q2 - q3q3) - mz);
	norm = sqrt(s1 * s1 + s2 * s2 + s3 * s3 + s4 * s4);    // normalise step magnitude
	if (norm == 0.0f) return; // handle NaN
	norm = 1.0f/norm;
	s1 *= norm;
	s2 *= norm;
	s3 *= norm;
	s4 *= norm;

	// Compute rate of change of quaternion
	qDot1 = 0.5f * (-q2 * gx - q3 * gy - q4 * gz) - beta * s1;
	qDot2 = 0.5f * (q1 * gx + q3 * gz - q4 * gy) - beta * s2;
	qDot3 = 0.5f * (q1 * gy - q2 * gz + q4 * gx) - beta * s3;
	qDot4 = 0.5f * (q1 * gz + q2 * gy - q3 * gx) - beta * s4;

	// Integrate to yield quaternion
	q1 += qDot1 * deltat;
	q2 += qDot2 * deltat;
	q3 += qDot3 * deltat;
	q4 += qDot4 * deltat;
	norm = sqrt(q1 * q1 + q2 * q2 + q3 * q3 + q4 * q4);    // normalise quaternion
	if (norm == 0.0f) return; // handle NaN
	norm = 1.0f/norm;
	dof.q[0] = q1 * norm;
	dof.q[1] = q2 * norm;
	dof.q[2] = q3 * norm;
	dof.q[3] = q4 * norm;

	// Calculate the pitch, roll and yaw
	dof.yaw_f    = atan2(2.0f * (dof.q[1] * dof.q[2] + dof.q[0] * dof.q[3]), dof.q[0] * dof.q[0] + dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] - dof.q[3] * dof.q[3]);
	//dof.yaw_f    = atan2(2.0f * (dof.q[1] * dof.q[2] + dof.q[0] * dof.q[3]), 1 + (2.0f * (dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3])));
	//dof.yaw_f    = atan2(2.0f * (dof.q[1] * dof.q[2] + dof.q[0] * dof.q[3]), dof.q[0] * dof.q[0] - dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3]);
	dof.roll_f  = -asin(2.0f * (dof.q[1] * dof.q[3] - dof.q[0] * dof.q[2]));
	dof.pitch_f   = atan2(2.0f * (dof.q[0] * dof.q[1] + dof.q[2] * dof.q[3]), dof.q[0] * dof.q[0] - dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3]);
	dof.pitch_f  *= 180.0f / M_PI;
	dof.yaw_f    *= 180.0f / M_PI;
	//dof.yaw_f   -= 24.8; // Declination at Danville, California is 13 degrees 48 minutes and 47 seconds on 2014-04-04
	dof.roll_f  *= 180.0f / M_PI;


}
/********************************************************
* FUNCTION: accelFilter
* DESCRIPTION: Only use the acceleration data, assuming
* 			   a desired low-pass filtered has been set
* 			   during initialization phase.
*
**********************************************************/
void accelFilter(LSM9DS0 & dof, float theta_rot_deg, float abias[3])
{

	// Initialize values
	float ax, ay, az;

	// Calculate the accelerometer data
	dof.readAccel();         				// Read raw accelerometer data
	ax = dof.calcAccel(dof.ax) - abias[0];  // Convert to g's, remove accelerometer biases
	ay = dof.calcAccel(dof.ay) - abias[1];
	az = dof.calcAccel(dof.az) - abias[2];

	// Rotate the data based on the platform's orientation (i.e., quadcopter frame/mount)
	// Use the rotation matrix Rz and rotate around the z-axis, i.e.:
	// http://en.wikipedia.org/wiki/Rotation_matrix
	if (theta_rot_deg > 0.0f)
	{
		float theta_rot = (theta_rot_deg * M_PI) * DEGREE_FULL_SCALE;
		float ax_r = (ax * cos(theta_rot)) - (ay * sin(theta_rot)) + 0.0f;
		float ay_r = (ax * sin(theta_rot)) + (ay * cos(theta_rot)) + 0.0f;
		float az_r = 0.0f + 0.0f + az;
		ax = ax_r;
		ay = ay_r;
		az = az_r;
	}

	// Update the converted values to the newly rotated ones
	dof.ax_c = ax;
	dof.ay_c = ay;
	dof.az_c = az;

}
/********************************************************
* FUNCTION: accelMFilter
* DESCRIPTION: Uses the Accel and Mag data, assuming
* 			   a desired low-pass filtered has been set
* 			   during initialization phase.
*
**********************************************************/
void accelMFilter(LSM9DS0 & dof, float theta_rot_deg, float abias[3])
{

	// Initialize values
	float ax, ay, az, mx, my, mz;

	// Calculate the accelerometer data
	dof.readAccel();         				// Read raw accelerometer data
	ax = dof.calcAccel(dof.ax) - abias[0];  // Convert to g's, remove accelerometer biases
	ay = dof.calcAccel(dof.ay) - abias[1];
	az = dof.calcAccel(dof.az) - abias[2];

	// Calculate the magnetometer data
	dof.readMag();           				// Read raw magnetometer data
	mx = dof.calcMag(dof.mx);     			// Convert to Gauss
	my = dof.calcMag(dof.my);
	mz = dof.calcMag(dof.mz);

	// Rotate the data based on the platform's orientation (i.e., quadcopter frame/mount)
	// Use the rotation matrix Rz and rotate around the z-axis, i.e.:
	// http://en.wikipedia.org/wiki/Rotation_matrix
	if (theta_rot_deg > 0.0f)
	{
		float theta_rot = (theta_rot_deg * M_PI) * DEGREE_FULL_SCALE;
		float ax_r = (ax * cos(theta_rot)) - (ay * sin(theta_rot)) + 0.0f;
		float ay_r = (ax * sin(theta_rot)) + (ay * cos(theta_rot)) + 0.0f;
		float az_r = 0.0f + 0.0f + az;
		ax = ax_r;
		ay = ay_r;
		az = az_r;

		float mx_r = (mx * cos(theta_rot)) - (my * sin(theta_rot)) + 0.0f;
		float my_r = (mx * sin(theta_rot)) + (my * cos(theta_rot)) + 0.0f;
		float mz_r = 0.0f + 0.0f + mz;
		mx = mx_r;
		my = my_r;
		mz = mz_r;
	}

	// Update the converted values to the newly rotated ones
	dof.ax_c = ax;
	dof.ay_c = ay;
	dof.az_c = az;

	dof.mx_c = mx;
	dof.my_c = my;
	dof.mz_c = mz;

}
/********************************************************
* FUNCTION: complementaryFilter
* DESCRIPTION: Fuses the sensor data from: Accel & Gyro
* 			   This filter gives us the best of both worlds
* 			   On the short term, it uses the data from
* 			   the gyroscope, because it is very precise
* 			   and not suceptible to external forces. On
* 			   the long term, it uses data from the Accel
* 			   since it does not drift. The basic eqn:
* 			   (1) theta = 0.98*(theta + gyr*dt) + 0.2*acc
*
**********************************************************/
void complementaryFilter(LSM9DS0 & dof, void * base_addr, float theta_rot_deg, float dt)
{

	// Initialize values
	float ax, ay, az, gx, gy, gz;

	// Convert raw Accel/Gyro counts to G's and deg/s
	dof.readAccel();         		// Read raw accelerometer data
	ax = dof.calcAccel(dof.ax);   	// Convert to g's
	ay = dof.calcAccel(dof.ay);
	az = dof.calcAccel(dof.az);

	dof.readGyro();           		// Read raw gyro data
	gx = dof.calcGyro(dof.gx);   	// Convert to degrees per seconds
	gy = dof.calcGyro(dof.gy);
	gz = dof.calcGyro(dof.gz);

	// Rotate the data based on the platform's orientation (i.e., quadcopter frame/mount)
	// Use the rotation matrix Rz and rotate around the z-axis, i.e.:
	// http://en.wikipedia.org/wiki/Rotation_matrix
	if (theta_rot_deg > 0.0f)
	{
		float theta_rot = (theta_rot_deg * M_PI) / 180.0f;
		float ax_r = (ax * cos(theta_rot)) - (ay * sin(theta_rot)) + 0.0f;
		float ay_r = (ax * sin(theta_rot)) + (ay * cos(theta_rot)) + 0.0f;
		float az_r = 0.0f + 0.0f + az;
		ax = ax_r;
		ay = ay_r;
		az = az_r;

		float gx_r = (gx * cos(theta_rot)) - (gy * sin(theta_rot)) + 0.0f;
		float gy_r = (gx * sin(theta_rot)) + (gy * cos(theta_rot)) + 0.0f;
		float gz_r = 0.0f + 0.0f + gz;
		gx = gx_r;
		gy = gy_r;
		gz = gz_r;
	}

	// Integrate the gyroscope data -> Int(deg/s) = deg
	dof.pitch_g += gx * dt;
	dof.roll_g += gy * dt;
	printf("Gyro (deg/s) = %1f, dt = %1f, pitch = %1f \r\n", gx, dt, dof.pitch_g);

	// Tune the pitch angle
	dof.pitch_a = atan2(ax, sqrt(ay * ay) + (az * az));
	dof.pitch_a *= 180.0f / M_PI;
	dof.pitch_f = dof.pitch_g * 0.98f + dof.pitch_a * 0.02f;

	// Tune the roll angle
	dof.roll_a = atan2(ay, sqrt(ax * ax) + (az * az));
	dof.roll_a *= 180.0f / M_PI;
	dof.roll_f = dof.roll_g * 0.98f + dof.roll_a * 0.02f;


}
/********************************************************************
* FUNCTION: calculateYaw
* DESCRIPTION: Uses the magnetometer and pitch/roll angles to
* 			   determine the Yaw angle
********************************************************************/
float calculateYaw(LSM9DS0 dof, float pitch, float roll)
{
	// To read from the magnetometer, you must first call the
	// readMag() function. When this exits, it'll update the
	// mx, my, and mz variables with the most current data.
	dof.readMag();

	// Convert to Gauss
	float magx = dof.calcMag(dof.mx);
	float magy = dof.calcMag(dof.my);
	float magz = dof.calcMag(dof.mz);
	/*float norm = sqrt(magx * magx + magy * magy + magz * magz);
	if (norm == 0.0f) return 0.0f; // handle NaN
	norm = 1.0f/norm;
	magx *= norm;
	magy *= norm;
	magz *= norm;*/

	float yaw = atan2( (-magy*cos(roll) + magz*sin(roll)) , (magx*cos(pitch) + magy*sin(pitch)*sin(roll)+ magz*sin(pitch)*cos(roll)));

	return yaw;
}
/********************************************************************************************
* FUNCTION: calculateOrientation
* DESCRIPTION: Calculates the orientation of the device based on the
* 			   data fused with the specified algorithm:
* 			   (1) Quaternion (Currently not working)
* 			   (2) Complementary filter (Faster: In progress)
*
* REFERENCES:   http://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles
*********************************************************************************************/
void calculateOrientation(LSM9DS0 & dof, int filter_mode)
{

	// Using Extended Kalman Filter (Quaternion's)
	if (FUSE_MODE == EXTENDED_KALMAN_FILTER)
	{
		dof.yaw_f    = atan2(2.0f * (dof.q[1] * dof.q[2] + dof.q[0] * dof.q[3]), dof.q[0] * dof.q[0] + dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] - dof.q[3] * dof.q[3]);
		dof.roll_f  = asin(2.0f * (dof.q[1] * dof.q[3] - dof.q[0] * dof.q[2]));
		dof.pitch_f   = atan2(2.0f * (dof.q[0] * dof.q[1] + dof.q[2] * dof.q[3]), dof.q[0] * dof.q[0] - dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3]);

		//dof.pitch_f   = atan2(2.0f * (dof.q[0] * dof.q[1] + dof.q[2] * dof.q[3]), 1.0f - 2.0f * (dof.q[1] * dof.q[1] + dof.q[2] * dof.q[2]));
		//dof.roll_f  = -asin(2.0f * (dof.q[1] * dof.q[3] - dof.q[0] * dof.q[2]));
		//dof.yaw_f   = atan2(2.0f * (dof.q[0] * dof.q[3] + dof.q[1] * dof.q[2]), 1.0f - 2.0f * (dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3]));

		dof.pitch_f  *= RAD_TO_DEGREES_SCALE;
		dof.yaw_f    *= RAD_TO_DEGREES_SCALE;
		//dof.yaw_f   -= 13.8; // Declination at Danville, California is 13 degrees 48 minutes and 47 seconds on 2014-04-04
		dof.roll_f  *= RAD_TO_DEGREES_SCALE;

	}
	// Using Complementary Filter: Working progress...
	else if (FUSE_MODE == COMPLEMENTARY_FILTER)
	{
	}
	// Accel only
	else if (FUSE_MODE == ACCEL_FILTER)
	{
		dof.roll_f   = atan2(dof.ax_c, sqrt(dof.ay_c * dof.ay_c) + (dof.az_c * dof.az_c));
		dof.pitch_f  = atan2(dof.ay_c, sqrt(dof.ax_c * dof.ax_c) + (dof.az_c * dof.az_c));
		dof.roll_f  *= RAD_TO_DEGREES_SCALE;
		dof.pitch_f *= RAD_TO_DEGREES_SCALE;
		dof.yaw_f    = 0.0f;
	}
	// Accel + Magnetometer
	else if (FUSE_MODE == ACCEL_MAG_FILTER)
	{
		// Accel
		dof.roll_f   = atan2(dof.ax_c, sqrt(dof.ay_c * dof.ay_c) + (dof.az_c * dof.az_c));
		dof.pitch_f  = atan2(dof.ay_c, sqrt(dof.ax_c * dof.ax_c) + (dof.az_c * dof.az_c));
		dof.roll_f  *= RAD_TO_DEGREES_SCALE;
		dof.pitch_f *= RAD_TO_DEGREES_SCALE;

		// Mag
		float hx = dof.mx_c;
		float hy = dof.my_c;
		if (hy > 0)
		{
			dof.yaw_f = 90.0f - (atan(hx / hy) * RAD_TO_DEGREES_SCALE);
		}
		else if (hy < 0)
		{
			dof.yaw_f = - (atan(hx / hy) * RAD_TO_DEGREES_SCALE);
		}
		else // hy = 0
		{
			if (hx < 0) dof.yaw_f = 180.0f;
			else dof.yaw_f = 0.0f;
		}

	}

	return;
}
/********************************************************
* FUNCTION: printGyroRAW
* DESCRIPTION: Reads from the gyro sensor to update
* 			   Gx, Gy and Gz. Prints the RAW values
**********************************************************/
void printGyroRAW(LSM9DS0 dof)
{
	// To read from the gyroscope, you must first call the
	// readGyro() function. When this exits, it'll update the
	// gx, gy, and gz variables with the most current data.
	dof.readGyro();

	printf("%d, %d, %d\r\n", dof.gx, dof.gy, dof.gz);
}
/***********************************************************
* FUNCTION: printGyroDPS
* DESCRIPTION: Reads from the gyro sensor to update
* 			   Gx, Gy and Gz. Prints the converted DPS values
************************************************************/
void printGyroDPS(LSM9DS0 dof)
{
	// To read from the gyroscope, you must first call the
	// readGyro() function. When this exits, it'll update the
	// gx, gy, and gz variables with the most current data.
	dof.readGyro();

	printf("%1f, %1f, %1f\r\n", dof.calcGyro(dof.gx), dof.calcGyro(dof.gy), dof.calcGyro(dof.gz));
}
/********************************************************
* FUNCTION: printAccelRAW
* DESCRIPTION: Reads from the Accel sensor to update
* 			   Ax, Ay and Az. Prints the RAW values
**********************************************************/
void printAccelRAW(LSM9DS0 dof)
{
	// To read from the accelerometer, you must first call the
	// readAccel() function. When this exits, it'll update the
	// ax, ay, and az variables with the most current data.
	dof.readAccel();

	printf("%d, %d, %d\r\n", dof.ax, dof.ay, dof.az);
}
/***********************************************************
* FUNCTION: printAccelG
* DESCRIPTION: Reads from the Accel sensor to update
* 			   Ax, Ay and Az. Prints the G's values
************************************************************/
void printAccelG(LSM9DS0 dof)
{
	// To read from the accelerometer, you must first call the
	// readAccel() function. When this exits, it'll update the
	// ax, ay, and az variables with the most current data.
	dof.readAccel();

	printf("%1f, %1f, %1f\r\n", dof.calcAccel(dof.ax), dof.calcAccel(dof.ay), dof.calcAccel(dof.az));
}
/********************************************************
* FUNCTION: printMagRAW
* DESCRIPTION: Reads from the Magnetomer sensor to update
* 			   Ax, Ay and Az. Prints the RAW values
**********************************************************/
void printMagRAW(LSM9DS0 dof)
{
	// To read from the magnetometer, you must first call the
	// readMag() function. When this exits, it'll update the
	// mx, my, and mz variables with the most current data.
	dof.readMag();

	printf("%d, %d, %d\r\n", dof.mx, dof.my, dof.mz);
}
/***********************************************************
* FUNCTION: printMagGauss
* DESCRIPTION: Reads from the Mag sensor to update
* 			   Mx, My and Mz. Prints the Gauss values
************************************************************/
void printMagGauss(LSM9DS0 dof)
{
	// To read from the magnetometer, you must first call the
	// readMag() function. When this exits, it'll update the
	// mx, my, and mz variables with the most current data.
	dof.readMag();

	printf("%1f, %1f, %1f\r\n", dof.calcMag(dof.mx), dof.calcMag(dof.my), dof.calcMag(dof.mz));
}
/********************************************************************
* FUNCTION: printHeading
* DESCRIPTION: Use the Earth's magnetic field to determine
* 			   the heading. This only works if the sensor
* 			   is flat (z-axis normal to Earth). Additionally,
* 			   you may need to add or subtract a declination
* 			   angle to get the heading normalization to your
* 			   location.
* 			   See: http://www.ngdc.noaa.gov/geomag/declination.shtml
********************************************************************/
void printHeading(LSM9DS0 dof)
{
	// To read from the magnetometer, you must first call the
	// readMag() function. When this exits, it'll update the
	// mx, my, and mz variables with the most current data.
	dof.readMag();

	// Calculate the heading
	float heading;
	float hx = dof.mx;
	float hy = dof.my;
	if (hy > 0)
	{
		heading = 90 - (atan(hx / hy) * (180 / M_PI));
	}
	else if (hy < 0)
	{
		heading = - (atan(hx / hy) * (180 / M_PI));
	}
	else // hy = 0
	{
		if (hx < 0) heading = 180;
		else heading = 0;
	}

	printf("Heading (degrees): %1f \r\n", heading);
}
/********************************************************************
* FUNCTION: getFlatYaw
* DESCRIPTION: Use the Earth's magnetic field to determine
* 			   the heading. This only works if the sensor
* 			   is flat (z-axis normal to Earth). Additionally,
* 			   you may need to add or subtract a declination
* 			   angle to get the heading normalization to your
* 			   location.
* 			   See: http://www.ngdc.noaa.gov/geomag/declination.shtml
********************************************************************/
float getFlatYaw(LSM9DS0 dof)
{
	// To read from the magnetometer, you must first call the
	// readMag() function. When this exits, it'll update the
	// mx, my, and mz variables with the most current data.
	dof.readMag();

	// Calculate the heading
	float heading;
	float hx = dof.mx;
	float hy = dof.my;
	if (hy > 0)
	{
		heading = 90 - (atan(hx / hy) * (180 / M_PI));
	}
	else if (hy < 0)
	{
		heading = - (atan(hx / hy) * (180 / M_PI));
	}
	else // hy = 0
	{
		if (hx < 0) heading = 180;
		else heading = 0;
	}


	return heading;
}
/********************************************************************
* FUNCTION: printOrientation
* DESCRIPTION: Performs the calculation based on the accelerometer
* 			   data. This function will print the LSM9DS0's
* 			   orientation: It's roll and pitch angles
********************************************************************/
void printOrientation(LSM9DS0 dof, float theta_rot_deg)
{
	// To read from the accelerometer, you must first call the
	// readAccel() function. When this exits, it'll update the
	// ax, ay, and az variables with the most current data.
	dof.readAccel();

	// Convert raw accel to G's
	float x = dof.calcAccel(dof.ax);
	float y = dof.calcAccel(dof.ay);
	float z = dof.calcAccel(dof.az);

	// Rotate the acceleration based on the platform's orientation (i.e., quadcopter frame/mount)
	// Use the rotation matrix Rz and rotate around the z-axis, i.e.:
	// http://en.wikipedia.org/wiki/Rotation_matrix
	float theta_rot = (theta_rot_deg * M_PI) / 180.0;
	float x_n = (x * cos(theta_rot)) - (y * sin(theta_rot)) + 0;
	float y_n = (x * sin(theta_rot)) + (y * cos(theta_rot)) + 0;
	float z_n = 0 + 0 + z;

	// Calculate the Pitch and Roll angles
	float pitch, roll;
	pitch = atan2(x_n, sqrt(y_n * y_n) + (z_n * z_n));
	roll = atan2(y_n, sqrt(x_n * x_n) + (z_n * z_n));
	pitch *= 180.0 / M_PI;
	roll *= 180.0 / M_PI;

	printf("Pitch, Roll (degrees): %1f, %1f \r\n", roll, pitch);
}
/********************************************************************
* FUNCTION: printFusedOrientation
* DESCRIPTION: Prints the orientation of the device based on the
* 			   data fused with the specified algorithm:
* 			   (1) Quaternion (Currently not working)
* 			   (2) Complementary filter (Faster: In progress)
********************************************************************/
void printFusedOrientation(LSM9DS0 dof, int filter_mode)
{

	// Using Quaternion's: Calculate the pitch, roll and yaw
	/*if (filter_mode == 1)
	{
		dof.yaw_f    = atan2(2.0f * (dof.q[1] * dof.q[2] + dof.q[0] * dof.q[3]), dof.q[0] * dof.q[0] + dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] - dof.q[3] * dof.q[3]);
		dof.roll_f  = -asin(2.0f * (dof.q[1] * dof.q[3] - dof.q[0] * dof.q[2]));
		dof.pitch_f   = atan2(2.0f * (dof.q[0] * dof.q[1] + dof.q[2] * dof.q[3]), dof.q[0] * dof.q[0] - dof.q[1] * dof.q[1] - dof.q[2] * dof.q[2] + dof.q[3] * dof.q[3]);
		dof.pitch_f  *= 180.0f / M_PI;
		dof.yaw_f    *= 180.0f / M_PI;
		dof.yaw_f   -= 13.8; // Declination at Danville, California is 13 degrees 48 minutes and 47 seconds on 2014-04-04
		dof.roll_f  *= 180.0f / M_PI;

	}
	// Using Complementary Filter: Do nothing, just print pitch and roll
	else
	{
	}*/

	// Accel: Print the pitch and roll angles
	//printf("[A] Pitch, Roll (deg): %0.1f, %0.1f\r\n", dof.pitch_a, dof.roll_a);

	// Gyro: Print the pitch and roll angles
	//printf("[G] Pitch, Roll (deg): %0.1f, %0.1f\r\n", dof.pitch_g, dof.roll_g);

	// Fused-Data: Print the pitch and roll angles
	printf("[F] Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof.pitch_f, dof.roll_f, dof.yaw_f);
}
/************************************************************
// FUNCTION: imu_test_mode
// DESCRIPTION: Provides menu to user to test IMU.
 * 				Menu options:
 * 				(Type any key to stop printing)
 * 				(1) Print RAW Gyro Data (ADC counts)
 * 				(2) Print RAW Accel Data (ADC counts)
 * 				(3) Print RAW Mag Data (ADC counts)
 * 				(4) Print CONV Gyro Data (DPS)
 * 				(5) Print CONV Accel Data (G's)
 * 				(6) Print CONV Mag Data (Gauss)
 *				(7) Print Heading (degrees)
 *				(8) Print Orientation (degrees)
 *
************************************************************/
void imu_test_mode(int imu_finger, void * base_addr_gyro[6], void * base_addr_xm[6], void * led_addr, void * custom_timer_addr)
{
	// Define single control variables
	int current_state_imu, next_state_imu;
	int menu_printed = 0;
	double dt = 0.0f;
	double DT = 0.01f;
	float abias[3] = {0.0f, 0.0f, 0.0f}, gbias[3] = {0.0f, 0.0f, 0.0f};
	char c_in = 'A';
	int i = 0, status = 0;
	unsigned int start_t, end_t;
	char *mode_display;
	LSM9DS0 dof;

	// Define combined control state variables
	LSM9DS0 dof_pinky, dof_ring, dof_middle, dof_index, dof_thumb, dof_wrist;
	int status_pinky, status_ring, status_middle, status_index, status_thumb, status_wrist;
	float abias_pinky[3] = {0.0f, 0.0f, 0.0f}, gbias_pinky[3] = {0.0f, 0.0f, 0.0f};
	float abias_ring[3] = {0.0f, 0.0f, 0.0f}, gbias_ring[3] = {0.0f, 0.0f, 0.0f};
	float abias_middle[3] = {0.0f, 0.0f, 0.0f}, gbias_middle[3] = {0.0f, 0.0f, 0.0f};
	float abias_index[3] = {0.0f, 0.0f, 0.0f}, gbias_index[3] = {0.0f, 0.0f, 0.0f};
	float abias_thumb[3] = {0.0f, 0.0f, 0.0f}, gbias_thumb[3] = {0.0f, 0.0f, 0.0f};
	float abias_wrist[3] = {0.0f, 0.0f, 0.0f}, gbias_wrist[3] = {0.0f, 0.0f, 0.0f};

	// Led state for sensor detections
	int led_mask = 0x01;
	*(uint32_t *)led_addr = led_mask;

	// ----------------------------------------------------------
	// Update the Menu based on the selected finger
	// ----------------------------------------------------------
	// Single sensor processing
	if (imu_finger != IMU_ALL)
	{
		current_state_imu = SINGLE_MAIN_MENU_IMU;
		next_state_imu = SINGLE_MAIN_MENU_IMU;

		// Initialize the LSM9DS0
		if (imu_finger == IMU_FINGER_PINKY)
		{
			mode_display = "PINKY";
			status = initSensor(dof, base_addr_gyro[0], base_addr_xm[0]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);

		}
		else if (imu_finger == IMU_FINGER_RING)
		{
			mode_display = "RING";
			status = initSensor(dof, base_addr_gyro[1], base_addr_xm[1]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);
		}
		else if (imu_finger == IMU_FINGER_MIDDLE)
		{
			mode_display = "MIDDLE";
			status = initSensor(dof, base_addr_gyro[2], base_addr_xm[2]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);
		}
		else if (imu_finger == IMU_FINGER_INDEX)
		{
			mode_display = "INDEX";
			status = initSensor(dof, base_addr_gyro[3], base_addr_xm[3]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);
		}
		else if (imu_finger == IMU_FINGER_THUMB)
		{
			mode_display = "THUMB";
			status = initSensor(dof, base_addr_gyro[4], base_addr_xm[4]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);
		}
		else if (imu_finger == IMU_WRIST)
		{
			mode_display = "WRIST";
			status = initSensor(dof, base_addr_gyro[5], base_addr_xm[5]);
			printf("[%s] gRes (After Init) = %1f \n", mode_display, dof.getgRes());
			printf("LSM9DS- WHO_AM_I's returned: 0x%1x \n", status);
			printf("Should be 0x49D4 \n");
			// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
			// all subsequent measurements.
			dof.calLSM9DS0(gbias, abias);
		}
	}
	// PROCESS ALL IMUs simultaneously
	else
	{
		current_state_imu = ALL_MAIN_MENU_IMU;
		next_state_imu = ALL_MAIN_MENU_IMU;
		mode_display = "ALL";

		// Initialize all sensors
		status_pinky = initSensor(dof_pinky, base_addr_gyro[0], base_addr_xm[0]);
		status_ring = initSensor(dof_ring, base_addr_gyro[1], base_addr_xm[1]);
		status_middle = initSensor(dof_middle, base_addr_gyro[2], base_addr_xm[2]);
		status_index = initSensor(dof_index, base_addr_gyro[3], base_addr_xm[3]);
		status_thumb = initSensor(dof_thumb, base_addr_gyro[4], base_addr_xm[4]);
		status_wrist = initSensor(dof_wrist, base_addr_gyro[5], base_addr_xm[5]);
		// Display status
		printf("---------------------------------\n");
		printf("(PINKY) gRes (After Init) = %1f \n", dof_pinky.getgRes());
		printf("(RING) gRes (After Init) = %1f \n", dof_ring.getgRes());
		printf("(MIDDLE) gRes (After Init) = %1f \n", dof_middle.getgRes());
		printf("(INDEX) gRes (After Init) = %1f \n", dof_index.getgRes());
		printf("(THUMB) gRes (After Init) = %1f \n", dof_thumb.getgRes());
		printf("(WRIST) gRes (After Init) = %1f \n", dof_wrist.getgRes());
		printf("---------------------------------\n");
		printf("(PINKY) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_pinky);
		printf("(RING) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_ring);
		printf("(MIDDLE) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_middle);
		printf("(INDEX) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_index);
		printf("(THUMB) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_thumb);
		printf("(WRIST) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_wrist);
		printf("***Each should be 0x49D4***\n");
		printf("***Averaging to get bias...\n");

		// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
		// all subsequent measurements.
		dof_pinky.calLSM9DS0(gbias_pinky, abias_pinky);
		printf("..PINKY Done\n");
		dof_ring.calLSM9DS0(gbias_ring, abias_ring);
		printf("..RING Done\n");
		dof_middle.calLSM9DS0(gbias_middle, abias_middle);
		printf("..MIDDLE Done\n");
		dof_index.calLSM9DS0(gbias_index, abias_index);
		printf("..INDEX Done\n");
		dof_thumb.calLSM9DS0(gbias_thumb, abias_thumb);
		printf("..THUMB Done\n");
		dof_wrist.calLSM9DS0(gbias_wrist, abias_wrist);
		printf("..WRIST Done\n");
	}

	clear();
	nonblock(NB_ENABLE);
	// ----------------------------------------------------------
	// IMU TEST State Machine
	// ----------------------------------------------------------
	while ((current_state_imu != SINGLE_EXIT_MAIN_MENU) && (current_state_imu != ALL_EXIT_MAIN_MENU))
	  {
		  /*** (SINGLE) IDLE STATE ***/
		  if (current_state_imu == SINGLE_MAIN_MENU_IMU)
		  {
			  // Print the Main Menu
			  if (menu_printed == 0)
			  {
				  printf ("*****************************************\n");
				  printf("Printing IMU Test Menu (%s)\n", mode_display);

				  // Create the TPA Control Menu
				  printf ("[0] Main Menu (%s)\n", mode_display);
				  printf ("[1] Print RAW Gyro Data (ADC counts)\n");
				  printf ("[2] Print RAW Accel Data (ADC counts)\n");
				  printf ("[3] Print RAW Mag Data (ADC counts)\n");
				  printf ("[4] Print CONV Gyro Data (DPS)\n");
				  printf ("[5] Print CONV Accel Data (G's)\n");
				  printf ("[6] Print CONV Mag Data (Gauss)\n");
				  printf ("[7] Print Heading (degrees)\n");
				  printf ("[8] Print Orientation (degrees)\n");
				  printf ("[9] Print Fused Orientation (degrees)\n");
				  printf ("[e/E] Exit Program\n");

				  menu_printed = 1;
			  }

			  // Obtain the selection from the user
			  c_in = getchar();									// Get a character from the UART

			  // Print Menu
			  if (c_in == '0')
			  {
				  menu_printed = 0;
				  clear();
				  next_state_imu = SINGLE_MAIN_MENU_IMU;
			  }

			  // Next state is: Print RAW Gyro Data
			  if (c_in == '1')
			  {

				  next_state_imu = SINGLE_PRINT_GYRO_RAW;
			  }

			  // Next state is: Print RAW Accel Data
			  else if (c_in == '2')
			  {
				  next_state_imu = SINGLE_PRINT_ACCEL_RAW;
			  }

			  // Next state is: Print RAW Mag Data
			  else if (c_in == '3')
			  {
				  next_state_imu = SINGLE_PRINT_MAG_RAW;
			  }

			  // Next state is: Print CONV Gyro Data
			  else if (c_in == '4')
			  {
				  next_state_imu = SINGLE_PRINT_GYRO_CONV;
			  }

			  // Next state is: Print CONV Accel Data
			  else if (c_in == '5')
			  {
				  next_state_imu = SINGLE_PRINT_ACCEL_CONV;
			  }

			  // Next state is: Print CONV Mag Data
			  else if (c_in == '6')
			  {
				  next_state_imu = SINGLE_PRINT_MAG_CONV;
			  }

			  // Next state is: Print Heading
			  else if (c_in == '7')
			  {
				  next_state_imu = SINGLE_PRINT_HEADING;
			  }

			  // Next state is: Print Orientation
			  else if (c_in == '8')
			  {
				  next_state_imu = SINGLE_PRINT_ORIENTATION;
			  }

			  // Next state is: Print Fused Orientation
			  else if (c_in == '9')
			  {
				  resetTimer(custom_timer_addr);
				  start_t = getCount(custom_timer_addr);		// Get start time for IMU fusion
				  next_state_imu = SINGLE_PRINT_FUSED_ORIENTATION;
			  }
			  else if (c_in == 'e' || c_in == 'E')
			  {
				  next_state_imu = SINGLE_EXIT_MAIN_MENU;
			  }

		  }

		  /*** (ALL) IDLE STATE ***/
		  if (current_state_imu == ALL_MAIN_MENU_IMU)
		  {
			  // Print the Main Menu
			  if (menu_printed == 0)
			  {
				  printf ("*****************************************\n");
				  printf("Printing IMU Test Menu (%s)\n", mode_display);

				  // Create the Control Menu
				  printf ("[0] Main Menu (%s)\n", mode_display);
				  printf ("[1] Print Orientation (degrees)\n");
				  printf ("[2] Print Fused Orientation (degrees)\n");
				  printf ("[e/E] Exit Program\n");

				  menu_printed = 1;
			  }

			  // Obtain the selection from the user
			  c_in = getchar();									// Get a character from the UART

			  // Print Menu
			  if (c_in == '0')
			  {
				  menu_printed = 0;
				  clear();
				  next_state_imu = ALL_MAIN_MENU_IMU;
			  }

			  // Next state is: Print Orientation
			  else if (c_in == '1')
			  {
				  next_state_imu = ALL_PRINT_ORIENTATION;
			  }

			  // Next state is: Print Fused Orientation
			  else if (c_in == '2')
			  {
				  resetTimer(custom_timer_addr);
				  start_t = getCount(custom_timer_addr);		// Get start time for IMU fusion
				  next_state_imu = ALL_PRINT_FUSED_ORIENTATION;
			  }
			  else if (c_in == 'e' || c_in == 'E')
			  {
				  next_state_imu = ALL_EXIT_MAIN_MENU;
			  }

		  }

		  /*** (SINGLE) PRINT RAW GYRO STATE ***/
		  if (current_state_imu == SINGLE_PRINT_GYRO_RAW)
		  {
			  printGyroRAW(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '1')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT RAW ACCEL STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_ACCEL_RAW)
		  {
			  printAccelRAW(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '2')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT RAW MAG STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_MAG_RAW)
		  {
			  printMagRAW(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '3')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT CONVERTED GYRO STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_GYRO_CONV)
		  {
			  printGyroDPS(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '4')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT CONVERTED ACCEL STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_ACCEL_CONV)
		  {
			  printAccelG(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '5')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT CONVERTED MAG STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_MAG_CONV)
		  {
			  printMagGauss(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '6')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT HEADING STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_HEADING)
		  {
			  printHeading(dof);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '7')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT ORIENTATION STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_ORIENTATION)
		  {
			  printOrientation(dof, 0);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '8')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (SINGLE) PRINT ORIENTATION STATE ***/
		  else if (current_state_imu == SINGLE_PRINT_FUSED_ORIENTATION)
		  {
			  end_t = getCount(custom_timer_addr);
			  dt = (double)(end_t - start_t) / (double)CUSTOM_CLOCKS_PER_SEC;

			  if (dt >= DT)
			  {
				  fuseSensor(dof, 45.0f, dt, abias, gbias);
				  printFusedOrientation(dof, 1);
				  printf("-----(dt = %1f)-----\n", dt);
				  start_t = getCount(custom_timer_addr);
			  }

			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '9')							// If current character is not stay in current state
				  {
					  next_state_imu = SINGLE_MAIN_MENU_IMU;
					  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (ALL) PRINT ORIENTATION STATE ***/
		  else if (current_state_imu == ALL_PRINT_ORIENTATION)
		  {
			  printf("-----------------------------------------\n");
			  printf("---(PINKY)---\n");
			  printOrientation(dof_pinky, 0);
			  printf("---(RING)---\n");
			  printOrientation(dof_ring, 0);
			  printf("---(MIDDLE)---\n");
			  printOrientation(dof_middle, 0);
			  printf("---(INDEX)---\n");
			  printOrientation(dof_index, 0);
			  printf("---(THUMB)---\n");
			  printOrientation(dof_thumb, 0);
			  printf("---(WRIST)---\n");
			  printOrientation(dof_wrist, 0);
			  usleep(DISP_DELAY_US);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '1')							// If current character is not stay in current state
				  {
					  next_state_imu = ALL_MAIN_MENU_IMU;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** (ALL) PRINT ORIENTATION STATE ***/
		  else if (current_state_imu == ALL_PRINT_FUSED_ORIENTATION)
		  {
			  end_t = getCount(custom_timer_addr);
			  dt = (double)(end_t - start_t) / (double)CUSTOM_CLOCKS_PER_SEC;

			  if (dt >= DT)
			  {
				  printf("-----------------------------------------\n");
				  // PINKY
				  printf("---(PINKY: dt = %1f)---\n", dt);
				  fuseSensor(dof_pinky, 45.0f, dt, abias_pinky, gbias_pinky);
				  printFusedOrientation(dof_pinky, 1);

				  // RING
				  printf("---(RING: dt = %1f)---\n", dt);
				  fuseSensor(dof_ring, 45.0f, dt, abias_ring, gbias_ring);
				  printFusedOrientation(dof_ring, 1);

				  // MIDDLE
				  printf("---(MIDDLE: dt = %1f)---\n", dt);
				  fuseSensor(dof_middle, 45.0f, dt, abias_middle, gbias_middle);
				  printFusedOrientation(dof_middle, 1);

				  // INDEX
				  printf("---(INDEX: dt = %1f)---\n", dt);
				  fuseSensor(dof_index, 45.0f, dt, abias_index, gbias_index);
				  printFusedOrientation(dof_index, 1);

				  // THUMB
				  printf("---(THUMB: dt = %1f)---\n", dt);
				  fuseSensor(dof_thumb, 45.0f, dt, abias_thumb, gbias_thumb);
				  printFusedOrientation(dof_thumb, 1);

				  // WRIST
				  printf("---(WRIST: dt = %1f)---\n", dt);
				  fuseSensor(dof_wrist, 45.0f, dt, abias_wrist, gbias_wrist);
				  printFusedOrientation(dof_wrist, 1);

				  start_t = getCount(custom_timer_addr);
			  }

			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '2')							// If current character is not stay in current state
				  {
					  next_state_imu = ALL_MAIN_MENU_IMU;
					  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }
		  end_t = getCount(custom_timer_addr);
		  current_state_imu = next_state_imu;
	  }

	nonblock(NB_DISABLE);
	return;
}
/************************************************************
// FUNCTION: resetTimer
// DESCRIPTION: Resets the custom FPGA timer
************************************************************/
void resetTimer(void * custom_timer_addr)
{
	// Write a 1 to the LSB before writting a zero
	*(uint32_t *)custom_timer_addr = 0x01;
	*(uint32_t *)custom_timer_addr = 0x00;
}
/************************************************************
// FUNCTION: getCount
// DESCRIPTION: Gets the current running count
************************************************************/
unsigned int getCount(void * custom_timer_addr)
{
	void * timer_reg = custom_timer_addr + (0X00000001)*4;
	unsigned int timer_count = *(unsigned long *)timer_reg;
	return timer_count;

}
// NON-BLOCKING USER INPUT IN LOOP WITHOUT NCURSES
// http://cc.byexamples.com/2007/04/08/non-blocking-user-input-in-loop-without-ncurses/
int kbhit()
{
    struct timeval tv;
    fd_set fds;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds); //STDIN_FILENO is 0
    select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
    return FD_ISSET(STDIN_FILENO, &fds);
}

void nonblock(int state)
{
    struct termios ttystate;

    //get the terminal state
    tcgetattr(STDIN_FILENO, &ttystate);

    if (state==NB_ENABLE)
    {
        //turn off canonical mode
        ttystate.c_lflag &= ~ICANON;
        //minimum of number input read.
        ttystate.c_cc[VMIN] = 1;
    }
    else if (state==NB_DISABLE)
    {
        //turn on canonical mode
        ttystate.c_lflag |= ICANON;
    }
    //set the terminal attributes.
    tcsetattr(STDIN_FILENO, TCSANOW, &ttystate);

}
