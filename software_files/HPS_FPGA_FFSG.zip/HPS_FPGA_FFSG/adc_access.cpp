/*
 * adc_access.cpp
 *
 *  Created on: Feb 4, 2018
 *  Modified on: Feb 4, 2018
 *      Author: Lloyd Emokpae
 *      Description:
 *      			 The module contains routines to access the LTC2308 ADC
 */

 #include <unistd.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <termios.h>
 #include <string.h>
 #include <stdint.h>
 #include <math.h>
 #include "adc_access.h"
 #include "imu_access.h"

 using namespace std;

/************************************************************
// FUNCTION: adc_test_mode
// DESCRIPTION: Provides menu to user to test ADC LTC2308.
 * 				Menu options:
 * 				(Type any key to stop printing)
 * 				(1) Channel 1 (Pressure: Center)
 * 				(2) Channel 2 (Pressure: Thumb)
 * 				(3) Channel 3 (Pressure: Middle)
 * 				(4) Channel 4 (Flex: Thumb)
 * 				(5) Channel 5 (Flex: Index)
 * 				(6) Channel 6 (Flex: Middle)
 *				(7) Channel 7 (Flex: Ring)
 *				(8) Channel 8 (Flex: Pinky)
 *				(9) All Channels (Pressure & Flex)
 *
************************************************************/
void adc_test_mode(void * base_addr_adc, void * led_addr, int readNum)
{
	// Define variables needed for application
	int current_state_adc, next_state_adc;
	int menu_printed = 0;
	char c_in = 'A';
	int test_read = 0;
	int i = 0, ch = 0, Value = 0;
	unsigned int SYSTEM_BUS_WIDTH = 32;			// SPI HDL uses 32-bit bus width
    void * LTC_0X00_ADDR = base_addr_adc + (0X00000000)*(SYSTEM_BUS_WIDTH/8);
	void * LTC_0X01_ADDR = base_addr_adc + (0X00000001)*(SYSTEM_BUS_WIDTH/8);
	float fsrV1 = 0.0, fsrV2 = 0.0, fsrV3 = 0.0, flexV4 = 0.0, flexV5 = 0.0, flexV6 = 0.0, flexV7 = 0.0, flexV8 = 0.0;
	float fsrR1 = 0.0, fsrR2 = 0.0, fsrR3 = 0.0, flexR4 = 0.0, flexR5 = 0.0, flexR6 = 0.0, flexR7 = 0.0, flexR8 = 0.0;
	float fsrG1 = 0.0, fsrG2 = 0.0, fsrG3 = 0.0;
	float force1 = 0.0, force2 = 0.0, force3 = 0.0;
	float angle4 = 0.0, angle5 = 0.0, angle6 = 0.0, angle7 = 0.0, angle8 = 0.0;

	// Led state for sensor detections
	int led_mask = 0x01;
	*(uint32_t *)led_addr = led_mask;

	current_state_adc = MAIN_MENU_ADC;
	next_state_adc = MAIN_MENU_ADC;

	// ----------------------------------------------------------
	// Update the Menu based on the selected finger
	// ----------------------------------------------------------

	clear();
	nonblock(NB_ENABLE);
	// ----------------------------------------------------------
	// ADC TEST State Machine
	// ----------------------------------------------------------
	while (current_state_adc != EXIT_MAIN_MENU_ADC)
	  {
		  /*** IDLE STATE ***/
		  if (current_state_adc == MAIN_MENU_ADC)
		  {
			  // Print the Main Menu
			  if (menu_printed == 0)
			  {
				  printf ("*****************************************\n");
				  printf("Printing ADC Test Menu (LTC2308)\n");

				  // Create the TPA Control Menu
				  printf ("[0] Main Menu (LTC2308)\n");
				  printf ("[1] Channel 1 (Pressure: Center)\n");
				  printf ("[2] Channel 2 (Pressure: Thumb)\n");
				  printf ("[3] Channel 3 (Pressure: Middle)\n");
				  printf ("[4] Channel 4 (Flex: Thumb)\n");
				  printf ("[5] Channel 5 (Flex: Index)\n");
				  printf ("[6] Channel 6 (FLex: Middle)\n");
				  printf ("[7] Channel 7 (Flex: Ring)\n");
				  printf ("[8] Channel 8 (Flex: Pinky)\n");
				  printf ("[9] ALL Channels (Pressure & Flex)\n");
				  printf ("[e/E] Exit Program\n");

				  menu_printed = 1;
			  }

			  // Obtain the selection from the user
			  c_in = getchar();									// Get a character from the UART

			  // Print Menu
			  if (c_in == '0')
			  {
				  menu_printed = 0;
				  clear();
				  next_state_adc = MAIN_MENU_ADC;
			  }

			  // Next state is: Print Channel 1
			  if (c_in == '1')
			  {
				  ch = 0;
				  next_state_adc = CHANNEL_1;
			  }

			  // Next state is: Print Channel 2
			  else if (c_in == '2')
			  {
				  ch = 1;
				  next_state_adc = CHANNEL_2;
			  }

			  // Next state is: Print Channel 3
			  else if (c_in == '3')
			  {
				  ch = 2;
				  next_state_adc = CHANNEL_3;
			  }

			  // Next state is: Print Channel 4
			  else if (c_in == '4')
			  {
				  ch = 3;
				  next_state_adc = CHANNEL_4;
			  }

			  // Next state is: Print Channel 5
			  else if (c_in == '5')
			  {
				  ch = 4;
				  next_state_adc = CHANNEL_5;
			  }

			  // Next state is: Print Channel 6
			  else if (c_in == '6')
			  {
				  ch = 5;
				  next_state_adc = CHANNEL_6;
			  }

			  // Next state is: Print Channel 7
			  else if (c_in == '7')
			  {
				  ch = 6;
				  next_state_adc = CHANNEL_7;
			  }

			  // Next state is: Print Channel 8
			  else if (c_in == '8')
			  {
				  ch = 7;
				  next_state_adc = CHANNEL_8;
			  }

			  // Next state is: Print All Channels
			  else if (c_in == '9')
			  {
				  next_state_adc = CHANNEL_ALL;
			  }
			  else if (c_in == 'e' || c_in == 'E')
			  {
				  next_state_adc = EXIT_MAIN_MENU_ADC;
			  }

		  }

		  /*** PRINT CHANNEL 1 (PRESSURE SENSOR: CENTER) STATE***/
		  if (current_state_adc == CHANNEL_1)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  fsrV1 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  fsrR1 = R_DIV1 * (VCC / fsrV1 - 1.0);

				  // Estimate the force slopes based on Figure 3 of the FSR data-sheet
				  fsrG1 = 1.0 / fsrR1;

				  // Break the parabolic curve down into two linear slopes:
				  if (fsrR1 <= 600)
				  {
					  force1 = (fsrG1 - 0.00075) / 0.00000032639;
				  }
				  else
				  {
					  force1 =  fsrG1 / 0.000000642857;
				  }
				  // Print the values
				  printf("[CH%d] fsrV1=%.3fV, fsrR1=%.3f ohms, Force = %.3f g\n", ch+1, fsrV1, fsrR1, force1);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '1')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 2 (PRESSURE SENSOR: THUMB) STATE***/
		  if (current_state_adc == CHANNEL_2)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  fsrV2 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  fsrR2 = R_DIV2 * (VCC / fsrV2 - 1.0);

				  // Estimate the force slopes based on Figure 3 of the FSR data-sheet
				  fsrG2 = 1.0 / fsrR2;

				  // Break the parabolic curve down into two linear slopes:
				  if (fsrR2 <= 600)
				  {
					  force2 = (fsrG2 - 0.00075) / 0.00000032639;
				  }
				  else
				  {
					  force2 =  fsrG2 / 0.000000642857;
				  }
				  // Print the values
				  printf("[CH%d] fsrV2=%.3fV, fsrR2=%.3f ohms, Force = %.3f g\n", ch+1, fsrV2, fsrR2, force2);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '2')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 3 (PRESSURE SENSOR: MIDDLE) STATE***/
		  if (current_state_adc == CHANNEL_3)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  fsrV3 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  fsrR3 = R_DIV3 * (VCC / fsrV3 - 1.0);

				  // Estimate the force slopes based on Figure 3 of the FSR data-sheet
				  fsrG3 = 1.0 / fsrR3;

				  // Break the parabolic curve down into two linear slopes:
				  if (fsrR3 <= 600)
				  {
					  force3 = (fsrG3 - 0.00075) / 0.00000032639;
				  }
				  else
				  {
					  force3 =  fsrG3 / 0.000000642857;
				  }
				  // Print the values
				  printf("[CH%d] fsrV3=%.3fV, fsrR3=%.3f ohms, Force = %.3f g\n", ch+1, fsrV3, fsrR3, force3);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '3')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 4 (FLEX SENSOR: THUMB) STATE***/
		  if (current_state_adc == CHANNEL_4)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  flexV4 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  flexR4 = R_DIV4 * (VCC / flexV4 - 1.0);

				  // Use the calculated resistance to estimate the sensor's bend angle:
				  angle4 = abs(map(flexR4, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

				  // Print the values
				  printf("[CH%d] flexV4=%.3fV, flexR4=%.3f ohms, Angle = %.3f degrees\n", ch+1, flexV4, flexR4, angle4);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '4')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 5 (FLEX SENSOR: INDEX) STATE***/
		  if (current_state_adc == CHANNEL_5)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  flexV5 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  flexR5 = R_DIV5 * (VCC / flexV5 - 1.0);

				  // Use the calculated resistance to estimate the sensor's bend angle:
				  angle5 = abs(map(flexR5, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

				  // Print the values
				  printf("[CH%d] flexV5=%.3fV, flexR5=%.3f ohms, Angle = %.3f degrees\n", ch+1, flexV5, flexR5, angle5);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '5')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 6 (FLEX SENSOR: MIDDLE) STATE***/
		  if (current_state_adc == CHANNEL_6)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  flexV6 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  flexR6 = R_DIV6 * (VCC / flexV6 - 1.0);

				  // Use the calculated resistance to estimate the sensor's bend angle:
				  angle6 = abs(map(flexR6, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

				  // Print the values
				  printf("[CH%d] flexV6=%.3fV, flexR6=%.3f ohms, Angle = %.3f degrees\n", ch+1, flexV6, flexR6, angle6);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '6')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 7 (FLEX SENSOR: RING) STATE***/
		  if (current_state_adc == CHANNEL_7)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  flexV7 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  flexR7 = R_DIV7 * (VCC / flexV7 - 1.0);

				  // Use the calculated resistance to estimate the sensor's bend angle:
				  angle7 = abs(map(flexR7, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

				  // Print the values
				  printf("[CH%d] flexV7=%.3fV, flexR7=%.3f ohms, Angle = %.3f degrees\n", ch+1, flexV7, flexR7, angle7);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '7')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL 8 (FLEX SENSOR: PINKY) STATE***/
		  if (current_state_adc == CHANNEL_8)
		  {
			  // set measure number for ADC convert
			  *(uint32_t *)LTC_0X01_ADDR = readNum;

			  // start measure
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
			  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
			  usleep(1);

			  // wait measure done
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  while ((test_read & 0x01) == 0x00)
			  {
				  test_read = *(uint32_t *)LTC_0X00_ADDR;
			  }

			  // read adc value
			  for(i=0;i<readNum;i++){
				  // Read raw ADC value
				  Value = *(uint32_t *)LTC_0X01_ADDR;

				  // Convert raw ADC value to voltage
				  flexV8 = (float)Value / 825.0;

				  // Use voltage and static resistor value to calculate FSR resistance
				  flexR8 = R_DIV8 * (VCC / flexV8 - 1.0);

				  // Use the calculated resistance to estimate the sensor's bend angle:
				  angle8 = abs(map(flexR8, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

				  // Print the values
				  printf("[CH%d] flexV8=%.3fV, flexR8=%.3f ohms, Angle = %.3f degrees\n", ch+1, flexV8, flexR8, angle8);
			  }
			  usleep(DELAY_BETWEEN_SAMPLES);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '8')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }

		  /*** PRINT CHANNEL ALL STATE***/
		  if (current_state_adc == CHANNEL_ALL)
		  {
			  // Get and convert each channel's data
			  force1 = getAndConvChannel(0, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV1, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  force2 = getAndConvChannel(1, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV2, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  force3 = getAndConvChannel(2, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV3, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  angle4 = getAndConvChannel(3, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV4, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  angle5 = getAndConvChannel(4, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV5, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  angle6 = getAndConvChannel(5, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV6, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  angle7 = getAndConvChannel(6, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV7, DELAY_BETWEEN_SAMPLES_ADC_TEST);
			  angle8 = getAndConvChannel(7, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV8, DELAY_BETWEEN_SAMPLES_ADC_TEST);

			  // Print all the values
			  printf("----------------------------------------------\n");
			  printf("[CH1: Center] Force = %.3f g\n", force1);
			  printf("[CH2: Thumb ] Force = %.3f g\n", force2);
			  printf("[CH3: Middle] Force = %.3f g\n", force3);
			  printf("[CH4: Thumb ] Angle = %.3f degrees\n", angle4);
			  printf("[CH5: Index ] Angle = %.3f degrees\n", angle5);
			  printf("[CH6: Middle] Angle = %.3f degrees\n", angle6);
			  printf("[CH7: Ring  ] Angle = %.3f degrees\n", angle7);
			  printf("[CH8: Pinky ] Angle = %.3f degrees\n", angle8);

			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '9')							// If current character is not stay in current state
				  {
					  next_state_adc = MAIN_MENU_ADC;
					  menu_printed = 0;
					  clear();
				  }
			  }
		  }
		  current_state_adc = next_state_adc;
	  }

	nonblock(NB_DISABLE);
	return;
}
/************************************************************
// FUNCTION: getAndConvChannel
// DESCRIPTION: Gets and converts the data from the specified
 * 				channel to the ADC.
 *
************************************************************/
float getAndConvChannel(int ch, void * LTC_0X00_ADDR, void * LTC_0X01_ADDR, float R_DIV, int DELAY_SAMPLES)
{
	int test_read = 0, Value = 0;
	float conversion = 0.0;
	float fsrflexV = 0.0, fsrflexR = 0.0, fsrG = 0.0;

	// ------------------
	// Pressure sensors
	// ------------------
	if (ch <= 2)
	{
		  // set measure number for ADC convert
		  *(uint32_t *)LTC_0X01_ADDR = 1;

		  // start measure
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
		  usleep(1);

		  // wait measure done
		  test_read = *(uint32_t *)LTC_0X00_ADDR;
		  while ((test_read & 0x01) == 0x00)
		  {
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
		  }

		  // Read raw ADC value
		  Value = *(uint32_t *)LTC_0X01_ADDR;

		  // Convert raw ADC value to voltage
		  fsrflexV = (float)Value / 825.0;

		  // Use voltage and static resistor value to calculate FSR resistance
		  fsrflexR = R_DIV * (VCC / fsrflexV - 1.0);

		  // Estimate the force slopes based on Figure 3 of the FSR data-sheet
		  fsrG = 1.0 / fsrflexR;

		  // Break the parabolic curve down into two linear slopes:
		  if (fsrflexR <= 600)
		  {
			  conversion = (fsrG - 0.00075) / 0.00000032639;
		  }
		  else
		  {
			  conversion =  fsrG / 0.000000642857;
		  }
		  usleep(DELAY_SAMPLES);
	}
	// ------------------
	// Flex sensors
	// ------------------
	else
	{
		  // set measure number for ADC convert
		  *(uint32_t *)LTC_0X01_ADDR = 1;

		  // start measure
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x01);
		  *(uint32_t *)LTC_0X00_ADDR = ((ch << 1) | 0x00);
		  usleep(1);

		  // wait measure done
		  test_read = *(uint32_t *)LTC_0X00_ADDR;
		  while ((test_read & 0x01) == 0x00)
		  {
			  test_read = *(uint32_t *)LTC_0X00_ADDR;
		  }

		  // Read raw ADC value
		  Value = *(uint32_t *)LTC_0X01_ADDR;

		  // Convert raw ADC value to voltage
		  fsrflexV = (float)Value / 825.0;

		  // Use voltage and static resistor value to calculate FSR resistance
		  fsrflexR = R_DIV * (VCC / fsrflexV - 1.0);

		  // Use the calculated resistance to estimate the sensor's bend angle:
		  conversion = abs(map(fsrflexR, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0));

		  usleep(DELAY_SAMPLES);
	}

	return conversion;
}

/************************************************************
// FUNCTION: map
// DESCRIPTION: Re-maps a number from one range to another.
 * 				That is, a value of fromLow would get mapped
 * 				to toLow, a value of fromHigh to toHigh,
 * 				values in-between to values in-between, etc.
 *
************************************************************/
long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
