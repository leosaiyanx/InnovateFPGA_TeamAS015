/*
 * main.cpp (FFSG)
 *
 * This program will define the application layer of the FFSG
 * project. The application will interface with the HDL routines to:
 * - Obtain pressure and flex information from the ADCs
 * - Obtain acceleration, angle and altitude from the IMU Interfaces
 * - Enable/Disable FPGA hardware acceleration for IMU sensor fusion
 * - Acquire, Process and Stream the FFSG data to a local host or storage
 *
 * The progress of this application can be found below:
 * 02/01/2018: Project Created, begin initial testing of IMU
 * 02/10/2018: - Completed test routines for IMU, pressure and flex sensors
 * 			   - Began application for streaming data to local host
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <iostream>
#include <cstdio>
//#include <math.h>

// Project Includes
#include "hps_0.h"
#include "imu_access.h"
#include "adc_access.h"
#include "imu_interface_lsm.h"

// TCP/IP sockets Includes
#include <sys/socket.h>
#include <arpa/inet.h>

// ----------------------------------------------
// General Definitions
// ----------------------------------------------
#define ALT_STM_OFST        0xfc000000 /* From socal/hps.h: The base address byte offset for the start of the ALT_STM component. */
#define ALT_LWFPGASLVS_OFST 0xff200000 /* From socal/hps.h: The base address byte offset for the start of the ALT_LWFPGASLVS component. */
#define HW_REGS_BASE 		( ALT_STM_OFST )
#define HW_REGS_SPAN 		( 0x04000000 )
#define HW_REGS_MASK 		( HW_REGS_SPAN - 1 )

// ----------------------------------------------
// Other cosntants
// ----------------------------------------------
#define MAX_SAMPLES			800000

#define ENABLE_PWM_INTERFACE	(PWM_INTERFACE_1_BASE + 0X00000000)
#define PWM_DUTY_CYCLE          (PWM_INTERFACE_1_BASE + (0X00000001)*4)

// ----------------------------------------------
// MAIN Menu State Machine
// ----------------------------------------------
#define MAIN_MENU_FFSG	        		1          // Main FFSG Menu
#define MAIN_FFSG_PROCESS        		2          // Main FFSG Data Processing, Acquisition and Stream to host
#define MAIN_TEST_IMU_PINKY        		3          // Test Pinky IMU
#define MAIN_TEST_IMU_RING        		4          // Test Ring IMU
#define MAIN_TEST_IMU_MIDDLE        	5          // Test Middle IMU
#define MAIN_TEST_IMU_INDEX        		6          // Test Index IMU
#define MAIN_TEST_IMU_THUMB        		7          // Test Thumb IMU
#define MAIN_TEST_IMU_WRIST        		8          // Test Wrist IMU
#define MAIN_TEST_IMU_ALL        		9          // Test ALL five IMUs (supports streaming to host)
#define MAIN_TEST_FLEX_PRESSURE	     	10         // Test Flex and Pressure Sensors
#define EXIT_MAIN_MENU_FFSG        		11         // Exits FFSG Main Menu

// STREAM/REPLAY/RECORD MENU
#define MAIN_MENU_FFSG_STREAM	        12         // Main FFSG Stream Menu
#define BEGIN_STREAMING					13		   // Begin data streaming
#define BEGIN_REPLAYING					14		   // Begin data replay (from disk)
#define BEGIN_RECORDING					15		   // Begin data record (to disk)
#define EXIT_STREAM_MENU				16		   // Exits stream menu

void main_menu_ffsg(void * h2p_base_addr_adc, void * h2p_base_addr_gyro[6], void * h2p_base_addr_xm[6], void * h2p_lw_led_addr, void * h2p_custom_timer_addr);
int ffsg_stream(void * h2p_base_addr_adc, void * h2p_base_addr_gyro[6], void * h2p_base_addr_xm[6], void * h2p_lw_led_addr, void * h2p_custom_timer_addr);
int package_data_to_send(char * message_buf, LSM9DS0 dof[6], float force1, float force2, float force3, float angle4, float angle5, float angle6, float angle7, float angle8);
void float2Bytes(char bytes_temp[4],float float_variable);
using namespace std;

/************************************************************
// FUNCTION: Main
// DESCRIPTION: Main function.
************************************************************/
int main() {

	void *h2p_lw_led_addr, *h2p_lw_button_addr, *h2p_lw_dip_addr;
	void *pwm_duty_cycle_address;
	void *h2p_custom_timer_addr;
	void *h2p_base_addr_adc;
	void *h2p_base_addr_gyro[6];			// Pointer array for all five finger gyro access
	void *h2p_base_addr_xm[6];				// Pointer array for all five finger xm access
	void *virtual_base;
	int fd;
	unsigned int pwm_duty_cycle = 2, pwm_duty_cycle_write = 0;

	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span

	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );

	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return( 1 );
	}

	//ADC ACCESS
	h2p_base_addr_adc = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + ADC_LTC2308_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//PINKY IMU ACCESS
	h2p_base_addr_gyro[0] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_PINKY_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[0] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_PINKY_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//RING IMU ACCESS
	h2p_base_addr_gyro[1] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_RING_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[1] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_RING_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//MIDDLE IMU ACCESS
	h2p_base_addr_gyro[2] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_MIDDLE_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[2] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_MIDDLE_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//INDEX IMU ACCESS
	h2p_base_addr_gyro[3] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_INDEX_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[3] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_INDEX_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//THUMB IMU ACCESS
	h2p_base_addr_gyro[4] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_THUMB_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[4] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_THUMB_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	//WRIST IMU ACCESS
	h2p_base_addr_gyro[5] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_GYRO_WRIST_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_base_addr_xm[5] = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + IMU_XM_WRIST_SPI_INTERFACE_BASE ) & ( unsigned long)( HW_REGS_MASK ) );


	// LED/BUTTON/DIP/PWM ACESS
	h2p_lw_led_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + LED_PIO_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_button_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + BUTTON_PIO_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_dip_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DIPSW_PIO_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_custom_timer_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + CUSTOM_TIMER_1_MHZ_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	pwm_duty_cycle_address = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PWM_INTERFACE_1_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	pwm_duty_cycle_address = pwm_duty_cycle_address + (0X00000001)*4;

	cout << "Enter Test PWM Write: " << endl;
	cin >> pwm_duty_cycle_write;

	*(uint32_t *)h2p_lw_led_addr = 0x05;
	sleep(1);
	*(uint32_t *)h2p_lw_led_addr = 0x02;

	*(unsigned long *)pwm_duty_cycle_address = pwm_duty_cycle_write;
	pwm_duty_cycle = *(unsigned long *)pwm_duty_cycle_address;
	printf("PWM Duty Cycle: %d\n", pwm_duty_cycle);

	// Call the main menu routine by passing the re-mapped base addresses
	main_menu_ffsg(h2p_base_addr_adc, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);

	// clean up our memory mapping and exit
	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );
	}

	close( fd );

	return( 0 );
}
/************************************************************
// FUNCTION: Main Menu FFSG
// DESCRIPTION: Main menu for the Flex Force Smart Glove
 * 				(0) Main Menu
 * 				(1) FFSG Data Processing, Acquisition and Stream
 * 				(2) Test IMU (PINKY)
 * 				(3) Test IMU (RING)
 * 				(4) Test IMU (MIDDLE)
 * 				(5)	Test IMU (INDEX)
 * 				(6) Test IMU (THUMB)
 * 				(7) Test IMU (ALL)
 * 				(8) Test Flex/Pressure (ALL)
 * 				(9) Exit Menu
************************************************************/
void main_menu_ffsg(void * h2p_base_addr_adc, void * h2p_base_addr_gyro[6], void * h2p_base_addr_xm[6], void * h2p_lw_led_addr, void * h2p_custom_timer_addr)
{
	// Define State Control Variables
	int current_state_main = MAIN_MENU_FFSG, next_state_main = MAIN_MENU_FFSG;
	int menu_printed = 0;
	char c_in = 'A';
	int i = 0;

	nonblock(NB_ENABLE);
	// ----------------------------------------------------------
	// FFSG TEST State Machine
	// ----------------------------------------------------------
	while (current_state_main != EXIT_MAIN_MENU_FFSG)
	  {
		  /*** IDLE STATE ***/
		  if (current_state_main == MAIN_MENU_FFSG)
		  {
			  // Print the Main Menu
			  if (menu_printed == 0)
			  {
				  printf ("*****************************************\n");
				  printf("FFSG Main Menu \n");
				  printf ("[0] Main Menu\n");
				  printf ("[1] FFSG Data Processing, Acquisition and Stream\n");
				  printf ("[2] Test IMU (PINKY)\n");
				  printf ("[3] Test IMU (RING)\n");
				  printf ("[4] Test IMU (MIDDLE)\n");
				  printf ("[5] Test IMU (INDEX)\n");
				  printf ("[6] Test IMU (THUMB)\n");
				  printf ("[7] Test IMU (WRIST)\n");
				  printf ("[8] Test IMU (ALL)\n");
				  printf ("[9] Test Flex/Pressure (ALL)\n");
				  printf ("[e/E] Exit Program\n");

				  menu_printed = 1;
			  }

			  // Obtain the selection from the user
			  c_in = getchar();									// Get a character from the UART

			  // Print Menu
			  if (c_in == '0')
			  {
				  menu_printed = 0;
				  next_state_main = MAIN_MENU_FFSG;
			  }

			  // Next state is: FFSG Main Processing
			  if (c_in == '1')
			  {

				  next_state_main = MAIN_FFSG_PROCESS;
			  }

			  // Next state is: Test IMU Pinky
			  else if (c_in == '2')
			  {
				  next_state_main = MAIN_TEST_IMU_PINKY;
			  }

			  // Next state is: Test IMU Ring
			  else if (c_in == '3')
			  {
				  next_state_main = MAIN_TEST_IMU_RING;
			  }

			  // Next state is: Test IMU Middle
			  else if (c_in == '4')
			  {
				  next_state_main = MAIN_TEST_IMU_MIDDLE;
			  }

			  // Next state is: Test IMU Index
			  else if (c_in == '5')
			  {
				  next_state_main = MAIN_TEST_IMU_INDEX;
			  }

			  // Next state is: Test IMU Thumb
			  else if (c_in == '6')
			  {
				  next_state_main = MAIN_TEST_IMU_THUMB;
			  }

			  // Next state is: Test IMU Wrist
			  else if (c_in == '7')
			  {
				  next_state_main = MAIN_TEST_IMU_WRIST;
			  }

			  // Next state is: Test IMU All
			  else if (c_in == '8')
			  {
				  next_state_main = MAIN_TEST_IMU_ALL;
			  }

			  // Next state is: Test Flex and Pressure Sensors
			  else if (c_in == '9')
			  {
				  next_state_main = MAIN_TEST_FLEX_PRESSURE;
			  }
			  else if (c_in == 'e' || c_in == 'E')
			  {
				  next_state_main = EXIT_MAIN_MENU_FFSG;
			  }

		  }

		  /*** FFSG PROCESSING STATE ***/
		  if (current_state_main == MAIN_FFSG_PROCESS)
		  {
			  clear();
			  ffsg_stream(h2p_base_addr_adc, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '1')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST PINKY STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_PINKY)
		  {
			  printf("\nInitializing IMU (PINKY)...\n");
			  imu_test_mode(IMU_FINGER_PINKY, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '2')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }

		  }

		  /*** TEST RING STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_RING)
		  {
			  printf("\nInitializing IMU (RING)...\n");
			  imu_test_mode(IMU_FINGER_RING, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '3')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST MIDDLE STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_MIDDLE)
		  {
			  printf("\nInitializing IMU (MIDDLE)...\n");
			  imu_test_mode(IMU_FINGER_MIDDLE, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '4')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST INDEX STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_INDEX)
		  {
			  printf("\nInitializing IMU (INDEX)...\n");
			  imu_test_mode(IMU_FINGER_INDEX, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '5')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST THUMB STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_THUMB)
		  {
			  printf("\nInitializing IMU (THUMB)...\n");
			  imu_test_mode(IMU_FINGER_THUMB, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '6')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST WRIST STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_WRIST)
		  {
			  printf("\nInitializing IMU (WRIST)...\n");
			  imu_test_mode(IMU_WRIST, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '7')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST ALL IMU STATE ***/
		  else if (current_state_main == MAIN_TEST_IMU_ALL)
		  {
			  printf("\nInitializing IMU (ALL)...\n");
			  imu_test_mode(IMU_ALL, h2p_base_addr_gyro, h2p_base_addr_xm, h2p_lw_led_addr, h2p_custom_timer_addr);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '8')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  /*** TEST ADC FLEX/PRESSURE STATE ***/
		  else if (current_state_main == MAIN_TEST_FLEX_PRESSURE)
		  {
			  printf("Initializing ADC (readNum = 3)...\n");
			  adc_test_mode(h2p_base_addr_adc, h2p_lw_led_addr, 3);
			  next_state_main = MAIN_MENU_FFSG;
			  menu_printed = 0;
			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '9')							// If current character is not stay in current state
				  {
					  next_state_main = MAIN_MENU_FFSG;
					  menu_printed = 0;
				  }
			  }
		  }

		  current_state_main = next_state_main;
	  }
}
/************************************************************
// FUNCTION: FFSG Stream
// DESCRIPTION: Acquires, Analyzes and Streams the FFSG data
 * 				to a local host server for visual analysis
************************************************************/
int ffsg_stream(void * base_addr_adc, void * base_addr_gyro[6], void * base_addr_xm[6], void * lw_led_addr, void * custom_timer_addr)
{
	// ------------------------
	// Initialize variables
	// ------------------------
	// Define State Control Variables
	int current_state_stream = MAIN_MENU_FFSG_STREAM, next_state_stream = MAIN_MENU_FFSG_STREAM;
	int menu_printed = 0;
	char c_in = 'A';
	int i = 0;
	unsigned int start_t, end_t;				// Needed for sensor fusion
	unsigned int start_stream_t, end_stream_t;	// Needed for data streaming
	unsigned int start_record_t, end_record_t;	// Needed for recording status
	double dt_stream = 0.0f, DT_stream = 0.1f;
	double dt_record = 0.0f, DT_record = 1.0f;

	// IMU Variables
	double dt = 0.0f;
	double DT = 0.01f;
	LSM9DS0 dof [6];
	int status_pinky, status_ring, status_middle, status_index, status_thumb, status_wrist;
	float abias_pinky[3] = {0.0f, 0.0f, 0.0f}, gbias_pinky[3] = {0.0f, 0.0f, 0.0f};
	float abias_ring[3] = {0.0f, 0.0f, 0.0f}, gbias_ring[3] = {0.0f, 0.0f, 0.0f};
	float abias_middle[3] = {0.0f, 0.0f, 0.0f}, gbias_middle[3] = {0.0f, 0.0f, 0.0f};
	float abias_index[3] = {0.0f, 0.0f, 0.0f}, gbias_index[3] = {0.0f, 0.0f, 0.0f};
	float abias_thumb[3] = {0.0f, 0.0f, 0.0f}, gbias_thumb[3] = {0.0f, 0.0f, 0.0f};
	float abias_wrist[3] = {0.0f, 0.0f, 0.0f}, gbias_wrist[3] = {0.0f, 0.0f, 0.0f};
	float wrist_gx = 0.0f, wrist_gy = 0.0f, wrist_gz = 0.0f;
	float wrist_ax = 0.0f, wrist_ay = 0.0f, wrist_az = 0.0f;
	float wrist_mx = 0.0f, wrist_my = 0.0f, wrist_mz = 0.0f;
	float wrist_pitch = 0.0f, wrist_roll = 0.0f, wrist_yaw = 0.0f;
	float thumb_gx = 0.0f, thumb_gy = 0.0f, thumb_gz = 0.0f;
	float thumb_ax = 0.0f, thumb_ay = 0.0f, thumb_az = 0.0f;
	float thumb_mx = 0.0f, thumb_my = 0.0f, thumb_mz = 0.0f;
	float thumb_pitch = 0.0f, thumb_roll = 0.0f, thumb_yaw = 0.0f;
	float index_gx = 0.0f, index_gy = 0.0f, index_gz = 0.0f;
	float index_ax = 0.0f, index_ay = 0.0f, index_az = 0.0f;
	float index_mx = 0.0f, index_my = 0.0f, index_mz = 0.0f;
	float index_pitch = 0.0f, index_roll = 0.0f, index_yaw = 0.0f;
	float middle_gx = 0.0f, middle_gy = 0.0f, middle_gz = 0.0f;
	float middle_ax = 0.0f, middle_ay = 0.0f, middle_az = 0.0f;
	float middle_mx = 0.0f, middle_my = 0.0f, middle_mz = 0.0f;
	float middle_pitch = 0.0f, middle_roll = 0.0f, middle_yaw = 0.0f;
	float ring_gx = 0.0f, ring_gy = 0.0f, ring_gz = 0.0f;
	float ring_ax = 0.0f, ring_ay = 0.0f, ring_az = 0.0f;
	float ring_mx = 0.0f, ring_my = 0.0f, ring_mz = 0.0f;
	float ring_pitch = 0.0f, ring_roll = 0.0f, ring_yaw = 0.0f;
	float pinky_gx = 0.0f, pinky_gy = 0.0f, pinky_gz = 0.0f;
	float pinky_ax = 0.0f, pinky_ay = 0.0f, pinky_az = 0.0f;
	float pinky_mx = 0.0f, pinky_my = 0.0f, pinky_mz = 0.0f;
	float pinky_pitch = 0.0f, pinky_roll = 0.0f, pinky_yaw = 0.0f;

	// ADC Pressure/Flex Sensor Variables
	unsigned int SYSTEM_BUS_WIDTH = 32;			// SPI HDL uses 32-bit bus width
    void * LTC_0X00_ADDR = base_addr_adc + (0X00000000)*(SYSTEM_BUS_WIDTH/8);
	void * LTC_0X01_ADDR = base_addr_adc + (0X00000001)*(SYSTEM_BUS_WIDTH/8);
	float force1 = 0.0, force2 = 0.0, force3 = 0.0;
	float angle4 = 0.0, angle5 = 0.0, angle6 = 0.0, angle7 = 0.0, angle8 = 0.0;

	// Buffers
	char * message_buf = (char*) malloc(MAX_SAMPLES * sizeof(char));
	char *message;

	// Socket Definitions
	int socket_desc, on = 1;
	struct sockaddr_in server;
	char server_ip[100] = "192.168.7.5";
	char local_ip[100] = "127.0.0.1";
	int loop_back_mode = 0;				// Print data locally via COM port
	int BASE_PACKET_SIZE = 540;			// Size of base packet (without Neural Network Classification data)

	// File Record/Replay Definitions
	FILE * fd_out_file, * fd_in_file;
	char out_filename [100] = "";
	char in_filename [100] = "Not Set";
	float skip_read = 0.0;
	int pc = 0, file_bytes = 0, file_size = 0;
	int replay_data_set = 0;

	// ---------------------------------
	// Setup client-server connection
	// ---------------------------------
	cout << "Enter Server IP Address: " << endl;
	cin >> server_ip;
	cout << "Server IP = " << server_ip << endl;

	// Loop back mode
	if (strcmp(server_ip, local_ip) == 0)
	{
		printf("***Loop-back Mode***\n");
		loop_back_mode = 1;
	}
	else
	{
		//Create socket
		socket_desc = socket(AF_INET , SOCK_STREAM , 0);
		if (socket_desc == -1)
		{
			printf("Could not create socket");
		}
		printf("Socket created\n");
		server.sin_addr.s_addr = inet_addr(server_ip);
		server.sin_family = AF_INET;
		server.sin_port = htons( 2000 );
		setsockopt(socket_desc, IPPROTO_TCP, O_NONBLOCK, (void*)&on, sizeof(on));

		//Connect to remote server
		printf("Connecting to server...\n");
		if (connect(socket_desc , (struct sockaddr *)&server , sizeof(server)) < 0)
		{
			printf("connect error\n");
			free(message_buf);		// Free the message buffer
			return 1;
		}
		printf("Connected to SERVER\n");
	}

	// ---------------------------------
	// Initialize IMUs
	// ---------------------------------
	status_pinky = initSensor(dof[0], base_addr_gyro[0], base_addr_xm[0]);
	status_ring = initSensor(dof[1], base_addr_gyro[1], base_addr_xm[1]);
	status_middle = initSensor(dof[2], base_addr_gyro[2], base_addr_xm[2]);
	status_index = initSensor(dof[3], base_addr_gyro[3], base_addr_xm[3]);
	status_thumb = initSensor(dof[4], base_addr_gyro[4], base_addr_xm[4]);
	status_wrist = initSensor(dof[5], base_addr_gyro[5], base_addr_xm[5]);
	// Display status
	printf("**************************************\n");
	printf("INITIALIZING IMUs...\n");
	printf("**************************************\n");
	printf("(PINKY) gRes (After Init) = %1f \n", dof[0].getgRes());
	printf("(RING) gRes (After Init) = %1f \n", dof[1].getgRes());
	printf("(MIDDLE) gRes (After Init) = %1f \n", dof[2].getgRes());
	printf("(INDEX) gRes (After Init) = %1f \n", dof[3].getgRes());
	printf("(THUMB) gRes (After Init) = %1f \n", dof[4].getgRes());
	printf("(WRIST) gRes (After Init) = %1f \n", dof[5].getgRes());
	printf("-----------------------------------------------\n");
	printf("(PINKY) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_pinky);
	printf("(RING) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_ring);
	printf("(MIDDLE) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_middle);
	printf("(INDEX) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_index);
	printf("(THUMB) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_thumb);
	printf("(WRIST) LSM9DS- WHO_AM_I's returned: 0x%1x \n", status_wrist);
	printf("***Each should be 0x49D4***\n");
	printf("***Averaging to get bias...\n");
	// Use the FIFO mode to average accelerometer and gyro readings to calculate the biases, which can then be removed from
	// all subsequent measurements.
	dof[0].calLSM9DS0(gbias_pinky, abias_pinky);
	printf("..PINKY Done\n");
	dof[1].calLSM9DS0(gbias_ring, abias_ring);
	printf("..RING Done\n");
	if (status_middle == 0x49D4) dof[2].calLSM9DS0(gbias_middle, abias_middle);
	printf("..MIDDLE Done\n");
	dof[3].calLSM9DS0(gbias_index, abias_index);
	printf("..INDEX Done\n");
	dof[4].calLSM9DS0(gbias_thumb, abias_thumb);
	printf("..THUMB Done\n");
	dof[5].calLSM9DS0(gbias_wrist, abias_wrist);
	printf("..WRIST Done\n");

	char bytes_temp[4];
	// ----------------------------------------------------------
	// FFSG STREAM State Machine
	// ----------------------------------------------------------
	clear();
	nonblock(NB_ENABLE);
	while (current_state_stream != EXIT_STREAM_MENU)
	  {
		  /****************************/
		  /*** IDLE STATE ***/
		  /****************************/
		  if (current_state_stream == MAIN_MENU_FFSG_STREAM)
		  {
			  // Print the Main Menu
			  if (menu_printed == 0)
			  {
				  printf ("*****************************************\n");
				  printf("FFSG Stream \n");
				  printf ("[0] Main Menu\n");
				  printf ("[1] Stream to Host (%s)\n", server_ip);
				  printf ("[2] Replay data (%s) to Host (%s) \n", in_filename, server_ip);
				  printf ("[3] Save data locally \n");
				  printf ("[4] Set Replay Data File \n");
				  printf ("[e/E] Exit to Main\n");

				  menu_printed = 1;
			  }

			  // Obtain the selection from the user
			  c_in = getchar();									// Get a character from the UART

			  // Print Menu
			  if (c_in == '0')
			  {
				  menu_printed = 0;
				  next_state_stream = MAIN_MENU_FFSG_STREAM;
			  }

			  // Next state is: FFSG Streaming
			  else if (c_in == '1')
			  {
				  resetTimer(custom_timer_addr);
				  start_t = getCount(custom_timer_addr);		// Get start time for IMU fusion
				  start_stream_t = start_t;
				  next_state_stream = BEGIN_STREAMING;
			  }

			  // Next state is: Replay recorded data
			  else if (c_in == '2')
			  {
				  // Only ask for file name if it hasn't been set
				  if (replay_data_set == 0)
				  {
					  replay_data_set = 1;
					  cout << endl << "Enter file name: " << endl;
					  cin >> in_filename;
					  cout << "File name = " << in_filename << endl;
					  fd_in_file = fopen(in_filename, "r");

				  }
				  else
				  {
					  fd_in_file = fopen(in_filename, "r");
				  }
				  // Check for valid file descriptor
				  if (fd_in_file == NULL)
				  {
					  printf("Error opening file");
					  menu_printed = 0;
					  next_state_stream = MAIN_MENU_FFSG_STREAM;
				  }
				  else
				  {
					  fseek(fd_in_file, 0L, SEEK_END);
					  file_size = ftell(fd_in_file);
					  rewind(fd_in_file);

					  resetTimer(custom_timer_addr);
					  start_t = getCount(custom_timer_addr);		// Get start time for IMU fusion
					  start_stream_t = start_t;
					  next_state_stream = BEGIN_REPLAYING;
					  file_bytes = 0;
					  printf("Replaying...\n");
				  }
			  }

			  // Next state is: Save data locally
			  else if (c_in == '3')
			  {
				  cout << endl << "Enter file name: " << endl;
				  cin >> out_filename;
				  cout << "File name = " << out_filename << endl;
				  fd_out_file = fopen(out_filename, "w");

				  // Check for valid file descriptor
				  if (fd_out_file == NULL)
				  {
					  printf("Error opening file");
					  menu_printed = 0;
					  next_state_stream = MAIN_MENU_FFSG_STREAM;
				  }
				  else
				  {
					  resetTimer(custom_timer_addr);
					  start_t = getCount(custom_timer_addr);		// Get start time for IMU fusion
					  start_stream_t = start_t;
					  start_record_t = end_t;
					  next_state_stream = BEGIN_RECORDING;
					  file_bytes = 0;
					  printf("Recording...\n");
				  }

			  }

			  // Next state is: Get replay file name
			  else if (c_in == '4')
			  {
				  replay_data_set = 1;
				  cout << endl << "Enter file name: " << endl;
				  cin >> in_filename;
				  cout << "File name = " << in_filename << endl;
				  fd_in_file = fopen(in_filename, "r");

				  menu_printed = 0;
				  next_state_stream = MAIN_MENU_FFSG_STREAM;
			  }

			  else if (c_in == 'e' || c_in == 'E')
			  {
				  next_state_stream = EXIT_STREAM_MENU;
			  }

		  }

		  /****************************/
		  /*** FFSG STREAMING STATE ***/
		  /****************************/
		  if (current_state_stream == BEGIN_STREAMING)
		  {
			  // Update the IMU/ADC data ever DT time
			  end_t = getCount(custom_timer_addr);
			  end_stream_t = end_t;
			  dt = (double)(end_t - start_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  dt_stream = (double)(end_stream_t - start_stream_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  // -----------------------------------------------------------
			  // Update sensor fusion every DT time (should be 0.01 seconds)
			  // -----------------------------------------------------------
			  if (dt >= DT)
			  {

				  // --------------------
				  // GET & FUSE IMU DATA
				  // --------------------
				  // PINKY
				  fuseSensor(dof[0], 45.0f, dt, abias_pinky, gbias_pinky);

				  // RING
				  fuseSensor(dof[1], 45.0f, dt, abias_ring, gbias_ring);

				  // MIDDLE
				  fuseSensor(dof[2], 45.0f, dt, abias_middle, gbias_middle);

				  // INDEX
				  fuseSensor(dof[3], 45.0f, dt, abias_index, gbias_index);

				  // THUMB
				  fuseSensor(dof[4], 45.0f, dt, abias_thumb, gbias_thumb);

				  // WRIST
				  fuseSensor(dof[5], 0.0f, dt, abias_wrist, gbias_wrist);

				  // -------------------------
				  // GET AND COMBINE ADC DATA
				  // -------------------------
				  // Get and convert each channel's data
				  force1 = getAndConvChannel(0, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV1, DELAY_BETWEEN_SAMPLES_STREAM);
				  force2 = getAndConvChannel(1, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV2, DELAY_BETWEEN_SAMPLES_STREAM);
				  force3 = getAndConvChannel(2, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV3, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle4 = getAndConvChannel(3, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV4, DELAY_BETWEEN_SAMPLES_STREAM);
				  if (angle4 > 60) angle4 = 60;				// Clip sampling errors
				  angle5 = getAndConvChannel(4, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV5, DELAY_BETWEEN_SAMPLES_STREAM);
				  if (angle5 > 60) angle5 = 60;				// Clip sampling errors
				  angle6 = getAndConvChannel(5, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV6, DELAY_BETWEEN_SAMPLES_STREAM);
				  if (angle6 > 60) angle6 = 60;				// Clip sampling errors
				  angle7 = getAndConvChannel(6, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV7, DELAY_BETWEEN_SAMPLES_STREAM);
				  if (angle7 > 60) angle7 = 60;				// Clip sampling errors
				  angle8 = getAndConvChannel(7, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV8, DELAY_BETWEEN_SAMPLES_STREAM);

				  start_t = getCount(custom_timer_addr);
			  }

			  // ------------------------------------------------
			  // Send data to server every 100 ms or 0.1 seconds
			  // ------------------------------------------------
			  if (dt_stream >= DT_stream)
			  {
				  // Package data to send and transmit to server
				  pc = package_data_to_send(message_buf, dof, force1, force2, force3, angle4, angle5, angle6, angle7, angle8);
				  message = message_buf;
				  send(socket_desc , message, pc , 0);

				  // (Loop-back Mode) Print all the values
				  if (loop_back_mode == 1)
				  {
					  printf("-----------------------------------------\n");
					  printf("---(dt = %1f)---\n", dt);
					  printf("[PINKY]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[0].pitch_f, dof[0].roll_f, dof[0].yaw_f);
					  printf("[RING]   Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[1].pitch_f, dof[1].roll_f, dof[1].yaw_f);
					  printf("[MIDDLE] Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[2].pitch_f, dof[2].roll_f, dof[2].yaw_f);
					  printf("[INDEX]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[3].pitch_f, dof[3].roll_f, dof[3].yaw_f);
					  printf("[THUMB]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[4].pitch_f, dof[4].roll_f, dof[4].yaw_f);
					  printf("[WRIST]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", dof[5].pitch_f, dof[5].roll_f, dof[5].yaw_f);
					  printf("----------------------------------------------\n");
					  printf("[CH1: Center] Force = %.3f g\n", force1);
					  printf("[CH2: Thumb ] Force = %.3f g\n", force2);
					  printf("[CH3: Middle] Force = %.3f g\n", force3);
					  printf("[CH4: Thumb ] Angle = %.3f degrees\n", angle4);
					  printf("[CH5: Index ] Angle = %.3f degrees\n", angle5);
					  printf("[CH6: Middle] Angle = %.3f degrees\n", angle6);
					  printf("[CH7: Ring  ] Angle = %.3f degrees\n", angle7);
					  printf("[CH8: Pinky ] Angle = %.3f degrees\n", angle8);

					  float2Bytes(bytes_temp, force1);
					  printf("----------------------------------------------\n");
					  printf("Sample Bytes[0]: %02x\n", bytes_temp[0]);
					  printf("Sample Bytes[1]: %02x\n", bytes_temp[1]);
					  printf("Sample Bytes[2]: %02x\n", bytes_temp[2]);
					  printf("Sample Bytes[3]: %02x\n", bytes_temp[3]);

				  }
				  else
				  {
					  printf("Transmitting to host (Sample check: Center Force = %.3f g) \n", force1);
					  printf("Packet Count = %d\n", pc);
				  }
				  start_stream_t = getCount(custom_timer_addr);
			  }

			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '1')							// If current character is not stay in current state
				  {
					  next_state_stream = MAIN_MENU_FFSG_STREAM;
					  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
					  menu_printed = 0;
					  fflush(stdout);
					  clear();
				  }
			  }
		  }

		  /****************************/
		  /*** FFSG REPLAYING STATE ***/
		  /****************************/
		  if (current_state_stream == BEGIN_REPLAYING)
		  {
			  // Update the IMU/ADC data ever DT time
			  end_t = getCount(custom_timer_addr);
			  end_stream_t = end_t;
			  dt = (double)(end_t - start_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  dt_stream = (double)(end_stream_t - start_stream_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  // ----------------------------------------------------------------------
			  // Read data from file every DT time (should be 0.01 seconds) and stream
			  // ----------------------------------------------------------------------
			  if (dt >= DT)
			  {

				  // ----------------------------------------
				  // Read data sample
				  // ----------------------------------------
				  pc = fread(message_buf, 1, BASE_PACKET_SIZE, fd_in_file);
				  file_bytes = file_bytes + pc;
				  message = message_buf;

				  // ----------------------------------------
				  // Extrapolate samples
				  // ----------------------------------------
				  // ----------
				  // Wrist
				  // ----------
				  // Wrist (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Wrist (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Wrist (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Wrist (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  wrist_yaw = *(float *)&bytes_temp;

				  // ----------
				  // Thumb
				  // ----------
				  // Thumb (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Thumb (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Thumb (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Thumb (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  thumb_yaw = *(float *)&bytes_temp;

				  // ----------
				  // Index
				  // ----------
				  // Index (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Index (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Index (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Index (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  index_yaw = *(float *)&bytes_temp;


				  // ----------
				  // Middle
				  // ----------
				  // Middle (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Middle (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Middle (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Middle (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  middle_yaw = *(float *)&bytes_temp;

				  // ----------
				  // Ring
				  // ----------
				  // Ring (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Ring (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Ring (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Ring (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  ring_yaw = *(float *)&bytes_temp;


				  // ----------
				  // Pinky
				  // ----------
				  // Pinky (gyro)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_gx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_gy = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_gz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Pinky (accel)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_ax = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_ay = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_az = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Pinky (mag)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_mx = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_my = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_mz = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  skip_read = *(float *)&bytes_temp;			// Only using raw samples for HW acceleration if enabled

				  // Pinky (pitch, roll, yaw)
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_pitch = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_roll = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  pinky_yaw = *(float *)&bytes_temp;

				  // --------------
				  // Force Sensors
				  // --------------
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  force1 = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  force2 = *(float *)&bytes_temp;
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  force3 = *(float *)&bytes_temp;

				  // --------------
				  // Flex Sensors
				  // --------------
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  angle4 = *(float *)&bytes_temp;
				  if (angle4 > 60) angle4 = 60;				// Clip sampling errors
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  angle5 = *(float *)&bytes_temp;
				  if (angle5 > 60) angle5 = 60;				// Clip sampling errors
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  angle6 = *(float *)&bytes_temp;
				  if (angle6 > 60) angle6 = 60;				// Clip sampling errors
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  angle7 = *(float *)&bytes_temp;
				  if (angle7 > 60) angle7 = 60;				// Clip sampling errors
				  message = message + 4;
				  memcpy(bytes_temp, message, 4);
				  angle8 = *(float *)&bytes_temp;

				  // ----------------------------------------
				  // Perform HW Acceleration if enabled (TBD)
				  // ----------------------------------------

				  // ----------------------------------------
				  // Prepare for next sample read
				  // ----------------------------------------
				  start_t = getCount(custom_timer_addr);
			  }

			  // ------------------------------------------------
			  // Send data to server every 100 ms or 0.1 seconds
			  // ------------------------------------------------
			  if (dt_stream >= DT_stream)
			  {
				  // Send data to socket
				  message = message_buf;
				  send(socket_desc , message, BASE_PACKET_SIZE , 0);

				  // (Loop-back Mode) Print some of the values
				  if (loop_back_mode == 1)
				  {
					  printf("-----------------------------------------\n");
					  printf("...(bytes read = %d Bytes OUT OF %d Bytes)\n", file_bytes, file_size);
					  printf("---(dt = %1f)---\n", dt);
					  printf("[PINKY]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", pinky_pitch, pinky_roll, pinky_yaw);
					  printf("[RING]   Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", ring_pitch, ring_roll, ring_yaw);
					  printf("[MIDDLE] Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", middle_pitch, middle_roll, middle_yaw);
					  printf("[INDEX]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", index_pitch, index_roll, index_yaw);
					  printf("[THUMB]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", thumb_pitch, thumb_roll, thumb_yaw);
					  printf("[WRIST]  Pitch, Roll, Yaw (deg): %0.1f, %0.1f, %0.1f \r\n\r\n", wrist_pitch, wrist_roll, wrist_yaw);
					  printf("----------------------------------------------\n");
					  printf("[CH1: Center] Force = %.3f g\n", force1);
					  printf("[CH2: Thumb ] Force = %.3f g\n", force2);
					  printf("[CH3: Middle] Force = %.3f g\n", force3);
					  printf("[CH4: Thumb ] Angle = %.3f degrees\n", angle4);
					  printf("[CH5: Index ] Angle = %.3f degrees\n", angle5);
					  printf("[CH6: Middle] Angle = %.3f degrees\n", angle6);
					  printf("[CH7: Ring  ] Angle = %.3f degrees\n", angle7);
					  printf("[CH8: Pinky ] Angle = %.3f degrees\n", angle8);

					  float2Bytes(bytes_temp, force1);
					  printf("----------------------------------------------\n");
					  printf("Sample Bytes[0]: %02x\n", bytes_temp[0]);
					  printf("Sample Bytes[1]: %02x\n", bytes_temp[1]);
					  printf("Sample Bytes[2]: %02x\n", bytes_temp[2]);
					  printf("Sample Bytes[3]: %02x\n", bytes_temp[3]);

				  }
				  else
				  {
					  printf("Transmitting to host (Sample check: Center Force = %.3f g) \n", force1);
					  printf("Packet Count = %d\n", pc);
				  }
				  start_stream_t = getCount(custom_timer_addr);
			  }

			  // ------------------------------------------------
			  // Stop after reaching file size
			  // ------------------------------------------------
			  if (file_bytes >= file_size)
			  {
				  next_state_stream = MAIN_MENU_FFSG_STREAM;
				  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
				  menu_printed = 0;
				  fflush(stdout);
				  clear();
				  fclose(fd_in_file);					// Close the data input file
			  }

			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '2')							// If current character is not stay in current state
				  {
					  next_state_stream = MAIN_MENU_FFSG_STREAM;
					  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
					  menu_printed = 0;
					  fflush(stdout);
					  clear();
					  fclose(fd_in_file);					// Close the data input file
				  }
			  }
		  }

		  /**************************************/
		  /*** FFSG RECORDING STATE (TO DISK) ***/
		  /**************************************/
		  else if (current_state_stream == BEGIN_RECORDING)
		  {
			  // Update the IMU/ADC data ever DT time
			  end_t = getCount(custom_timer_addr);
			  end_record_t = end_t;
			  dt = (double)(end_t - start_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  dt_record = (double)(end_record_t - start_record_t) / (double)CUSTOM_CLOCKS_PER_SEC;
			  // -----------------------------------------------------------
			  // Update sensor fusion every DT time (should be 0.01 seconds)
			  // -----------------------------------------------------------
			  if (dt >= DT)
			  {
				  // --------------------
				  // GET & FUSE IMU DATA
				  // --------------------
				  // PINKY
				  fuseSensor(dof[0], 45.0f, dt, abias_pinky, gbias_pinky);

				  // RING
				  fuseSensor(dof[1], 45.0f, dt, abias_ring, gbias_ring);

				  // MIDDLE
				  fuseSensor(dof[2], 45.0f, dt, abias_middle, gbias_middle);

				  // INDEX
				  fuseSensor(dof[3], 45.0f, dt, abias_index, gbias_index);

				  // THUMB
				  fuseSensor(dof[4], 45.0f, dt, abias_thumb, gbias_thumb);

				  // WRIST
				  fuseSensor(dof[5], 0.0f, dt, abias_wrist, gbias_wrist);

				  // -------------------------
				  // GET AND COMBINE ADC DATA
				  // -------------------------
				  // Get and convert each channel's data
				  force1 = getAndConvChannel(0, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV1, DELAY_BETWEEN_SAMPLES_STREAM);
				  force2 = getAndConvChannel(1, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV2, DELAY_BETWEEN_SAMPLES_STREAM);
				  force3 = getAndConvChannel(2, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV3, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle4 = getAndConvChannel(3, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV4, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle5 = getAndConvChannel(4, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV5, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle6 = getAndConvChannel(5, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV6, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle7 = getAndConvChannel(6, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV7, DELAY_BETWEEN_SAMPLES_STREAM);
				  angle8 = getAndConvChannel(7, LTC_0X00_ADDR, LTC_0X01_ADDR, R_DIV8, DELAY_BETWEEN_SAMPLES_STREAM);

				  // Package data to record
				  pc = package_data_to_send(message_buf, dof, force1, force2, force3, angle4, angle5, angle6, angle7, angle8);
				  file_bytes = file_bytes + pc;
				  message = message_buf;

				  /* Write data to disk*/
				  fwrite(message_buf, 1, pc, fd_out_file);

				  // Prepare for next sample
				  start_t = getCount(custom_timer_addr);
			  }

			  // ------------------------------------------------
			  // Display recording status once every second
			  // ------------------------------------------------
			  if (dt_record >= DT_record)
			  {
				  printf("...(current file size = %d bytes)\n", file_bytes);
				  start_record_t = getCount(custom_timer_addr);
			  }

			  nonblock(NB_ENABLE);
			  // Obtain the selection from the user and return to Main Menu if received
			  i = kbhit();
			  if (i != 0)
			  {
				  c_in = fgetc(stdin);
				  if (c_in != '3')							// If current character is not stay in current state
				  {
					  next_state_stream = MAIN_MENU_FFSG_STREAM;
					  resetTimer(custom_timer_addr);		// Reset the custom FPGA timer
					  menu_printed = 0;
					  fflush(stdout);
					  clear();
					  fclose(fd_out_file);					// Close the data output file
				  }
			  }
		  }

		  current_state_stream = next_state_stream;
	  }

	// -----------------------------------
	// Close-out socket and clear buffers
	// -----------------------------------
	free(message_buf);		// Free the message buffer
	close(socket_desc);		// Close the TCP/IP socket

}

/************************************************************
// FUNCTION: Package Data to Send
// DESCRIPTION: Packages the data to send to the local host
************************************************************/
int package_data_to_send(char * message_buf, LSM9DS0 dof[6], float force1, float force2, float force3, float angle4, float angle5, float angle6, float angle7, float angle8)
{
	char current_bytes[4];
	int pc = 0;

	// -----------------------
	// DATA PACKAGE HEADER
	// -----------------------
	message_buf[pc] = 0x5d;
	message_buf[pc+1] = 0x3c;
	message_buf[pc+2] = 0x7f;
	message_buf[pc+3] = 0x4e;
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU WRIST PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// WRIST (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[5].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[5].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[5].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[5].calcGyro(dof[5].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[5].calcGyro(dof[5].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[5].calcGyro(dof[5].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// WRIST (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[5].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[5].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[5].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[5].calcAccel(dof[5].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[5].calcAccel(dof[5].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[5].calcAccel(dof[5].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// WRIST (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[5].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[5].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[5].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[5].calcMag(dof[5].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[5].calcMag(dof[5].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[5].calcMag(dof[5].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// WRIST (PITCH)
	float2Bytes(current_bytes, dof[5].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (ROLL)
	float2Bytes(current_bytes, dof[5].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// WRIST (YAW)
	float2Bytes(current_bytes, dof[5].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU THUMB PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// THUMB (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[4].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[4].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[4].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[4].calcGyro(dof[4].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[4].calcGyro(dof[4].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[4].calcGyro(dof[4].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// THUMB (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[4].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[4].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[4].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[4].calcAccel(dof[4].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[4].calcAccel(dof[4].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[4].calcAccel(dof[4].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// THUMB (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[4].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[4].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[4].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[4].calcMag(dof[4].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[4].calcMag(dof[4].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[4].calcMag(dof[4].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// THUMB (PITCH)
	float2Bytes(current_bytes, dof[4].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (ROLL)
	float2Bytes(current_bytes, dof[4].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// THUMB (YAW)
	float2Bytes(current_bytes, dof[4].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU INDEX PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// INDEX (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[3].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[3].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[3].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[3].calcGyro(dof[3].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[3].calcGyro(dof[3].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[3].calcGyro(dof[3].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// INDEX (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[3].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[3].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[3].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[3].calcAccel(dof[3].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[3].calcAccel(dof[3].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[3].calcAccel(dof[3].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// INDEX (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[3].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[3].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[3].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[3].calcMag(dof[3].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[3].calcMag(dof[3].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[3].calcMag(dof[3].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// INDEX (PITCH)
	float2Bytes(current_bytes, dof[3].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (ROLL)
	float2Bytes(current_bytes, dof[3].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// INDEX (YAW)
	float2Bytes(current_bytes, dof[3].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU MIDDLE PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// MIDDLE (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[2].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[2].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[2].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[2].calcGyro(dof[2].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[2].calcGyro(dof[2].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[2].calcGyro(dof[2].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// MIDDLE (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[2].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[2].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[2].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[2].calcAccel(dof[2].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[2].calcAccel(dof[2].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[2].calcAccel(dof[2].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// MIDDLE (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[2].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[2].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[2].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[2].calcMag(dof[2].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[2].calcMag(dof[2].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[2].calcMag(dof[2].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// MIDDLE (PITCH)
	float2Bytes(current_bytes, dof[2].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (ROLL)
	float2Bytes(current_bytes, dof[2].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// MIDDLE (YAW)
	float2Bytes(current_bytes, dof[2].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU RING PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// RING (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[1].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[1].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[1].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[1].calcGyro(dof[1].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[1].calcGyro(dof[1].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[1].calcGyro(dof[1].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// RING (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[1].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[1].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[1].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[1].calcAccel(dof[1].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[1].calcAccel(dof[1].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[1].calcAccel(dof[1].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// RING (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[1].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[1].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[1].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[1].calcMag(dof[1].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[1].calcMag(dof[1].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[1].calcMag(dof[1].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// RING (PITCH)
	float2Bytes(current_bytes, dof[1].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (ROLL)
	float2Bytes(current_bytes, dof[1].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// RING (YAW)
	float2Bytes(current_bytes, dof[1].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// IMU PINKY PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// GYRO DATA
	// ------------------------
	// PINKY (RAW Gyro Data: X)
	float2Bytes(current_bytes, dof[0].gx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Gyro Data: Y)
	float2Bytes(current_bytes, dof[0].gy);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Gyro Data: Z)
	float2Bytes(current_bytes, dof[0].gz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Gyro Data: X)
	float2Bytes(current_bytes, dof[0].calcGyro(dof[0].gx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Gyro Data: Y)
	float2Bytes(current_bytes, dof[0].calcGyro(dof[0].gy));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Gyro Data: Z)
	float2Bytes(current_bytes, dof[0].calcGyro(dof[0].gz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ACCEL DATA
	// ------------------------
	// PINKY (RAW Accel Data: X)
	float2Bytes(current_bytes, dof[0].ax);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Accel Data: Y)
	float2Bytes(current_bytes, dof[0].ay);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Accel Data: Z)
	float2Bytes(current_bytes, dof[0].az);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Accel Data: X)
	float2Bytes(current_bytes, dof[0].calcAccel(dof[0].ax));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Accel Data: Y)
	float2Bytes(current_bytes, dof[0].calcAccel(dof[0].ay));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Accel Data: Z)
	float2Bytes(current_bytes, dof[0].calcAccel(dof[0].az));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// MAGNETOMETER DATA
	// ------------------------
	// PINKY (RAW Mag Data: X)
	float2Bytes(current_bytes, dof[0].mx);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Mag Data: Y)
	float2Bytes(current_bytes, dof[0].my);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (RAW Mag Data: Z)
	float2Bytes(current_bytes, dof[0].mz);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Mag Data: X)
	float2Bytes(current_bytes, dof[0].calcMag(dof[0].mx));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Mag Data: Y)
	float2Bytes(current_bytes, dof[0].calcMag(dof[0].my));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (CONVERTED Mag Data: Z)
	float2Bytes(current_bytes, dof[0].calcMag(dof[0].mz));
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// FUSED DATA
	// ------------------------
	// PINKY (PITCH)
	float2Bytes(current_bytes, dof[0].pitch_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (ROLL)
	float2Bytes(current_bytes, dof[0].roll_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// PINKY (YAW)
	float2Bytes(current_bytes, dof[0].yaw_f);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// -----------------------------------------------------------------
	// PRESSURE/FLEX SENSORS PACKAGE
	// -----------------------------------------------------------------
	// ------------------------
	// FORCE SENSORS
	// ------------------------
	// FORCE 1
	float2Bytes(current_bytes, force1);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// FORCE 2
	float2Bytes(current_bytes, force2);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// FORCE 3
	float2Bytes(current_bytes, force3);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ------------------------
	// ANGLE SENSORS
	// ------------------------
	// ANGLE 4
	float2Bytes(current_bytes, angle4);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ANGLE 5
	float2Bytes(current_bytes, angle5);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ANGLE 6
	float2Bytes(current_bytes, angle6);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ANGLE 7
	float2Bytes(current_bytes, angle7);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	// ANGLE 8
	float2Bytes(current_bytes, angle8);
	message_buf[pc] = current_bytes[0];
	message_buf[pc+1] = current_bytes[1];
	message_buf[pc+2] = current_bytes[2];
	message_buf[pc+3] = current_bytes[3];
	pc = pc + 4;

	return pc;
}
/************************************************************
// FUNCTION: Float 2 Bytes
// DESCRIPTION: Converts the float value into four bytes
************************************************************/
void float2Bytes(char bytes_temp[4],float float_variable){
  union {
    float a;
    unsigned char bytes[4];
  } thing;
  thing.a = float_variable;
  memcpy(bytes_temp, thing.bytes, 4);
}


