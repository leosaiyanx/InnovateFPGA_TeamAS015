/*
 * imu_access.h
 *
 *  Created on: Feb 1, 2018
 *  Modified on: Feb 1, 2018
 *      Author: Lloyd Emokpae
 *      Description:
 *      			 The module contains routines to access the 9DOF IMU to:
 *      			 (1) Print Gyro, Accel and Mag to screen
 *      			 (2) Print heading and orientation to screen
 */

#ifndef IMU_ACCESS_H_
#define IMU_ACCESS_H_

#include "imu_interface_lsm.h"
//#include "imu_interface_lsm_ring.h"
//#include "imu_interface_lsm_middle.h"
//#include "imu_interface_lsm_index.h"
//#include "imu_interface_lsm_thumb.h"

#define NB_ENABLE 	1
#define NB_DISABLE	2
#define DISP_DELAY_US 100000
#define CUSTOM_CLOCKS_PER_SEC	1000000
#define IMU_FINGER_PINKY	1
#define IMU_FINGER_RING		2
#define IMU_FINGER_MIDDLE	3
#define IMU_FINGER_INDEX	4
#define IMU_FINGER_THUMB	5
#define IMU_WRIST			6
#define IMU_ALL				7

// ----------------------------------------------
// IMU Access State Machine
// (MAIN)
// ----------------------------------------------
#define MAIN_MENU_IMU    			20        	// Main Menu
#define ALL_SENSORS					21			// Main Menu for all sensors
#define SINGLE_MAIN_MENU_IMU    	21        	// Main Menu: single sensors
#define ALL_MAIN_MENU_IMU    		22        	// Main Menu: all sensors
#define EXIT_MAIN_MENU				26			// Exit Main Menu

// ----------------------------------------------
// IMU Access State Machine
// (ALL 5 Sensors)
// ----------------------------------------------
#define ALL_PRINT_GYRO_RAW        		27          // Prints RAW Gyro
#define ALL_PRINT_ACCEL_RAW        		28          // Prints RAW Accel
#define ALL_PRINT_MAG_RAW        		29          // Prints RAW Mag
#define ALL_PRINT_GYRO_CONV        		30          // Prints Converted Gyro
#define ALL_PRINT_ACCEL_CONV        	31          // Prints Converted Accel
#define ALL_PRINT_MAG_CONV        		32          // Prints Converted Mag
#define ALL_PRINT_HEADING        		33          // Prints the Heading
#define ALL_PRINT_ORIENTATION        	34          // Prints the Orientation
#define ALL_PRINT_FUSED_ORIENTATION     35          // Prints the Fused Orientation
#define ALL_EXIT_MAIN_MENU        		36          // Exits All sensors Menu

// ----------------------------------------------
// IMU Access State Machine
// (Single Sensor)
// ----------------------------------------------
#define SINGLE_PRINT_GYRO_RAW        	37          // Prints RAW Gyro
#define SINGLE_PRINT_ACCEL_RAW        	38          // Prints RAW Accel
#define SINGLE_PRINT_MAG_RAW        	39          // Prints RAW Mag
#define SINGLE_PRINT_GYRO_CONV        	40          // Prints Converted Gyro
#define SINGLE_PRINT_ACCEL_CONV        	41          // Prints Converted Accel
#define SINGLE_PRINT_MAG_CONV        	42          // Prints Converted Mag
#define SINGLE_PRINT_HEADING        	43          // Prints the Heading
#define SINGLE_PRINT_ORIENTATION        44          // Prints the Orientation
#define SINGLE_PRINT_FUSED_ORIENTATION  45          // Prints the Fused Orientation
#define SINGLE_EXIT_MAIN_MENU        	46          // Exits Menu

// ----------------------------------------------
// IMU Access State Machine
// (Ring Sensor)
// ----------------------------------------------
#define RING_PRINT_GYRO_RAW        		47          // Prints RAW Gyro
#define RING_PRINT_ACCEL_RAW        	48          // Prints RAW Accel
#define RING_PRINT_MAG_RAW        		49          // Prints RAW Mag
#define RING_PRINT_GYRO_CONV        	50          // Prints Converted Gyro
#define RING_PRINT_ACCEL_CONV        	51          // Prints Converted Accel
#define RING_PRINT_MAG_CONV        		52          // Prints Converted Mag
#define RING_PRINT_HEADING        		53          // Prints the Heading
#define RING_PRINT_ORIENTATION        	54          // Prints the Orientation
#define RING_PRINT_FUSED_ORIENTATION    55          // Prints the Fused Orientation
#define RING_EXIT_MAIN_MENU        		56          // Exits Menu

// ----------------------------------------------
// IMU Access State Machine
// (Middle Sensor)
// ----------------------------------------------
#define MIDDLE_PRINT_GYRO_RAW        	57          // Prints RAW Gyro
#define MIDDLE_PRINT_ACCEL_RAW        	58          // Prints RAW Accel
#define MIDDLE_PRINT_MAG_RAW        	59          // Prints RAW Mag
#define MIDDLE_PRINT_GYRO_CONV        	60          // Prints Converted Gyro
#define MIDDLE_PRINT_ACCEL_CONV        	61          // Prints Converted Accel
#define MIDDLE_PRINT_MAG_CONV        	62          // Prints Converted Mag
#define MIDDLE_PRINT_HEADING        	63          // Prints the Heading
#define MIDDLE_PRINT_ORIENTATION        64          // Prints the Orientation
#define MIDDLE_PRINT_FUSED_ORIENTATION  65          // Prints the Fused Orientation
#define MIDDLE_EXIT_MAIN_MENU        	66          // Exits Menu

// ----------------------------------------------
// IMU Access State Machine
// (Index Sensor)
// ----------------------------------------------
#define INDEX_PRINT_GYRO_RAW        	67          // Prints RAW Gyro
#define INDEX_PRINT_ACCEL_RAW        	68          // Prints RAW Accel
#define INDEX_PRINT_MAG_RAW        		69          // Prints RAW Mag
#define INDEX_PRINT_GYRO_CONV        	70          // Prints Converted Gyro
#define INDEX_PRINT_ACCEL_CONV        	71          // Prints Converted Accel
#define INDEX_PRINT_MAG_CONV        	72          // Prints Converted Mag
#define INDEX_PRINT_HEADING        		73          // Prints the Heading
#define INDEX_PRINT_ORIENTATION        	74          // Prints the Orientation
#define INDEX_PRINT_FUSED_ORIENTATION  	75          // Prints the Fused Orientation
#define INDEX_EXIT_MAIN_MENU        	76          // Exits Menu

// ----------------------------------------------
// IMU Access State Machine
// (Thumb Sensor)
// ----------------------------------------------
#define THUMB_PRINT_GYRO_RAW        	77          // Prints RAW Gyro
#define THUMB_PRINT_ACCEL_RAW        	78          // Prints RAW Accel
#define THUMB_PRINT_MAG_RAW        		79          // Prints RAW Mag
#define THUMB_PRINT_GYRO_CONV        	80          // Prints Converted Gyro
#define THUMB_PRINT_ACCEL_CONV        	81          // Prints Converted Accel
#define THUMB_PRINT_MAG_CONV        	82          // Prints Converted Mag
#define THUMB_PRINT_HEADING        		83          // Prints the Heading
#define THUMB_PRINT_ORIENTATION        	84          // Prints the Orientation
#define THUMB_PRINT_FUSED_ORIENTATION  	85          // Prints the Fused Orientation
#define THUMB_EXIT_MAIN_MENU        	86          // Exits Menu

// ----------------------------------------------
// Function Prototypes
// (All Sensors): FPGA Acceleration needed
// ----------------------------------------------
int initSensor(LSM9DS0 & dof, void * base_addr_gyro, void * base_addr_xm);
float getFlatYaw(LSM9DS0 dof);
float calculateYaw(LSM9DS0 dof, float pitch, float roll);
void calculateOrientation(LSM9DS0 & dof, int filter_mode);
void printGyroRAW(LSM9DS0 dof);
void printGyroDPS(LSM9DS0 dof);
void fuseIMU(LSM9DS0 & dof, float theta_rot_deg, float deltat, float abias[3], float gbias[3]);
void fuseSensor(LSM9DS0 & dof, float theta_rot_deg, float deltat, float abias[3], float gbias[3]);
void complementaryFilter(LSM9DS0 & dof, float theta_rot_deg, float dt);
void accelFilter(LSM9DS0 & dof, float theta_rot_deg, float abias[3]);
void accelMFilter(LSM9DS0 & dof, float theta_rot_deg, float abias[3]);
void resetTimer(void * custom_timer_addr);
unsigned int getCount(void * custom_timer_addr);
void imu_test_mode(int imu_finger, void * base_addr_gyro[6], void * base_addr_xm[6], void * led_addr, void * custom_timer_addr);

#define clear() printf("\033[H\033[J")
int kbhit();
void nonblock(int state);

#endif /* IMU_ACCESS_H_ */
