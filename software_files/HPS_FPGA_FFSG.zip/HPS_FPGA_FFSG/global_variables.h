/*
 * global_variables.h
 *
 *  Created on: Fab 1, 2018
 *  Modified  : February 22, 2018
 *      Author: Lloyd Emokpae
 *      Description: This module is used to define global variables used in the main program and classes.
 */

#ifndef GLOBAL_VARIABLES_H_
#define GLOBAL_VARIABLES_H_

// -------------------------------------
// Some other GLOBAL constants/functions
// -------------------------------------
#define DELAY_1000MS 				1000000
#define DELAY_500MS 				500000
#define DELAY_100MS 				100000
#define DELAY_20MS 					20000
#define DELAY_10MS 					10000
#define DELAY_5MS 					5000
#define DELAY_1MS 					1000
#define MAX_WAIT_LOOP				50000
#define UART_BUFFER					500
#define THROTTLE_SCALE				0.00392156862f
#define DEGREE_SCALE				0.01111111111f						// 0 to +-90 degrees
#define DEGREE_FULL_SCALE			0.00555555555f						// 0 to +-180 degrees
#define RAD_TO_DEGREES_SCALE		57.2957795100f
#define DEGREES_TO_RAD_SCALE		0.01745329250f
#define DEGREES_MAX_ALLOWED			90

// Local Commands (Slave to Master)
#define REMOTE_IMU_INFO		0x28

// Sensor Fusion Modes
#define EXTENDED_KALMAN_FILTER	1										// Implements an Extended Kalman Filter
#define COMPLEMENTARY_FILTER	2										// Implements a Complementary fiter
#define	ACCEL_FILTER			3										// Uses only the accelerometer
#define ACCEL_MAG_FILTER		4										// USes the accelerometer for pitch and roll, uses the magnetometer for yaw
#define FUSE_MODE				ACCEL_FILTER

// Sensor Locations
#define PINKY					1
#define RING					2
#define MIDDLE					3
#define	INDEX					4
#define	THUMB					5

// DEBUG
#define DEBUG_ENABLE				1

#endif /* GLOBAL_VARIABLES_H_ */
